# Q10. Write a Python program to validate user input for age, email, and phone number
# using exception handling with try-except blocks.

import re


def validate_age(age_input):
    """Validate user age input."""
    try:
        age = int(age_input)
        if age < 0:
            raise ValueError("Age cannot be negative!")
        elif age > 150:
            raise ValueError("Age cannot be greater than 150!")
        return age
    except ValueError as e:
        if "invalid literal" in str(e):
            raise ValueError("Age must be a numeric value!")
        raise


def validate_email(email):
    """Validate email format using regex."""
    # Basic email pattern: something@something.something
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, email):
        raise ValueError("Invalid email format! Example: user@example.com")
    return email


def validate_phone(phone):
    """Validate phone number (10-digit Indian format)."""
    # Remove spaces and hyphens
    cleaned_phone = phone.replace(" ", "").replace("-", "")

    # Remove country code if present
    if cleaned_phone.startswith("+91"):
        cleaned_phone = cleaned_phone[3:]
    elif cleaned_phone.startswith("91") and len(cleaned_phone) == 12:
        cleaned_phone = cleaned_phone[2:]

    if not cleaned_phone.isdigit():
        raise ValueError("Phone number must contain only digits!")
    if len(cleaned_phone) != 10:
        raise ValueError("Phone number must be exactly 10 digits!")
    if cleaned_phone[0] not in '6789':
        raise ValueError("Phone number must start with 6, 7, 8, or 9!")
    return cleaned_phone


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   USER INPUT VALIDATION PROGRAM")
    print("=" * 50)

    # Validate Age
    print("\n--- Age Validation ---")
    while True:
        try:
            age_input = input("Enter your age: ")
            age = validate_age(age_input)
            print(f"✅ Valid age: {age}")
            break
        except ValueError as e:
            print(f"❌ Error: {e}")
            print("Please try again.\n")

    # Validate Email
    print("\n--- Email Validation ---")
    while True:
        try:
            email = input("Enter your email: ")
            validated_email = validate_email(email)
            print(f"✅ Valid email: {validated_email}")
            break
        except ValueError as e:
            print(f"❌ Error: {e}")
            print("Please try again.\n")

    # Validate Phone Number
    print("\n--- Phone Number Validation ---")
    while True:
        try:
            phone = input("Enter your phone number: ")
            validated_phone = validate_phone(phone)
            print(f"✅ Valid phone number: {validated_phone}")
            break
        except ValueError as e:
            print(f"❌ Error: {e}")
            print("Please try again.\n")

    # Display all validated information
    print("\n" + "=" * 50)
    print("   VALIDATED USER INFORMATION")
    print("=" * 50)
    print(f"   Age   : {age}")
    print(f"   Email : {validated_email}")
    print(f"   Phone : {validated_phone}")
    print("=" * 50)


# Expected Output:
# ==================================================
#    USER INPUT VALIDATION PROGRAM
# ==================================================
#
# --- Age Validation ---
# Enter your age: abc
# ❌ Error: Age must be a numeric value!
# Please try again.
#
# Enter your age: -5
# ❌ Error: Age cannot be negative!
# Please try again.
#
# Enter your age: 25
# ✅ Valid age: 25
#
# --- Email Validation ---
# Enter your email: invalid
# ❌ Error: Invalid email format! Example: user@example.com
# Please try again.
#
# Enter your email: student@gmail.com
# ✅ Valid email: student@gmail.com
#
# --- Phone Number Validation ---
# Enter your phone number: 12345
# ❌ Error: Phone number must be exactly 10 digits!
# Please try again.
#
# Enter your phone number: 9876543210
# ✅ Valid phone number: 9876543210
#
# ==================================================
#    VALIDATED USER INFORMATION
# ==================================================
#    Age   : 25
#    Email : student@gmail.com
#    Phone : 9876543210
# ==================================================
