# Q15. Write a Pandas program to read employee data from a CSV file and display
# department-wise average salary using groupby.

import pandas as pd


def create_sample_csv(filename):
    """Create a sample employee CSV file for demonstration."""
    data = {
        'EmpID': ['E001', 'E002', 'E003', 'E004', 'E005', 
                  'E006', 'E007', 'E008', 'E009', 'E010'],
        'Name': ['Rahul Sharma', 'Priya Singh', 'Amit Kumar', 'Sneha Patel', 'Rohan Verma',
                 'Kavita Joshi', 'Deepak Gupta', 'Anita Reddy', 'Suresh Nair', 'Meera Das'],
        'Department': ['IT', 'HR', 'IT', 'Finance', 'IT',
                       'HR', 'Finance', 'IT', 'HR', 'Finance'],
        'Salary': [55000, 48000, 62000, 58000, 70000,
                   52000, 65000, 60000, 45000, 72000]
    }

    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"✅ Sample CSV file '{filename}' created successfully!")
    return df


def analyze_employee_data(filename):
    """Read employee CSV and display department-wise average salary."""
    try:
        # Read CSV file
        df = pd.read_csv(filename)

        # Display all employee data
        print("\n" + "=" * 60)
        print("   ALL EMPLOYEE DATA")
        print("=" * 60)
        print(df.to_string(index=False))

        # Department-wise average salary using groupby
        dept_avg_salary = df.groupby('Department')['Salary'].mean()

        print("\n" + "=" * 60)
        print("   DEPARTMENT-WISE AVERAGE SALARY")
        print("=" * 60)
        print(f"\n{'Department':<15} {'Avg Salary':>15}")
        print("-" * 35)
        for dept, avg_sal in dept_avg_salary.items():
            print(f"{dept:<15} ₹{avg_sal:>14.2f}")

        # Additional analysis
        print("\n" + "=" * 60)
        print("   DEPARTMENT-WISE DETAILED STATISTICS")
        print("=" * 60)
        dept_stats = df.groupby('Department')['Salary'].agg(['count', 'min', 'max', 'mean', 'sum'])
        dept_stats.columns = ['Count', 'Min Salary', 'Max Salary', 'Avg Salary', 'Total Salary']
        print(dept_stats)

        # Highest paying department
        highest_dept = dept_avg_salary.idxmax()
        print(f"\n🏆 Highest Paying Department: {highest_dept} (Avg: ₹{dept_avg_salary[highest_dept]:.2f})")

        # Lowest paying department
        lowest_dept = dept_avg_salary.idxmin()
        print(f"📉 Lowest Paying Department: {lowest_dept} (Avg: ₹{dept_avg_salary[lowest_dept]:.2f})")

    except FileNotFoundError:
        print(f"❌ File '{filename}' not found!")
    except Exception as e:
        print(f"❌ Error: {e}")


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   EMPLOYEE DATA ANALYSIS WITH PANDAS")
    print("=" * 50)

    filename = "employee_data.csv"

    print("\n1. Create sample CSV and analyze")
    print("2. Analyze existing CSV file")
    choice = input("\nEnter your choice (1/2): ")

    if choice == '1':
        create_sample_csv(filename)
        analyze_employee_data(filename)
    elif choice == '2':
        csv_file = input("Enter CSV filename: ").strip()
        analyze_employee_data(csv_file)
    else:
        print("❌ Invalid choice!")


# Expected Output:
# ==================================================
#    EMPLOYEE DATA ANALYSIS WITH PANDAS
# ==================================================
#
# ✅ Sample CSV file 'employee_data.csv' created successfully!
#
# ============================================================
#    ALL EMPLOYEE DATA
# ============================================================
# EmpID          Name Department  Salary
#  E001  Rahul Sharma         IT   55000
#  E002   Priya Singh         HR   48000
#  ...
#
# ============================================================
#    DEPARTMENT-WISE AVERAGE SALARY
# ============================================================
#
# Department       Avg Salary
# -----------------------------------
# Finance         ₹     65000.00
# HR              ₹     48333.33
# IT              ₹     61750.00
#
# 🏆 Highest Paying Department: Finance (Avg: ₹65000.00)
# 📉 Lowest Paying Department: HR (Avg: ₹48333.33)
