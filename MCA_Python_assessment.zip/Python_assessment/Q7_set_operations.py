# Q7. Write a Python program to perform set operations - union, intersection,
# difference, and subset operations on two sets entered by the user.

def perform_set_operations(set1, set2):
    """Perform various set operations on two sets."""
    results = {
        "Union": set1 | set2,
        "Intersection": set1 & set2,
        "Difference (Set1 - Set2)": set1 - set2,
        "Difference (Set2 - Set1)": set2 - set1,
        "Symmetric Difference": set1 ^ set2,
        "Is Set1 subset of Set2": set1.issubset(set2),
        "Is Set2 subset of Set1": set2.issubset(set1),
        "Is Set1 superset of Set2": set1.issuperset(set2),
        "Is Set2 superset of Set1": set2.issuperset(set1),
    }
    return results


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   SET OPERATIONS PROGRAM")
    print("=" * 55)

    # Accept two sets from user
    input1 = input("\nEnter elements of Set 1 (space-separated): ")
    set1 = set(map(int, input1.split()))

    input2 = input("Enter elements of Set 2 (space-separated): ")
    set2 = set(map(int, input2.split()))

    # Display original sets
    print(f"\nSet 1: {set1}")
    print(f"Set 2: {set2}")

    # Perform set operations
    results = perform_set_operations(set1, set2)

    # Display results
    print("\n" + "=" * 55)
    print("   RESULTS OF SET OPERATIONS")
    print("=" * 55)

    for operation, result in results.items():
        print(f"{operation:<30} : {result}")


# Expected Output:
# =======================================================
#    SET OPERATIONS PROGRAM
# =======================================================
#
# Enter elements of Set 1 (space-separated): 1 2 3 4 5
# Enter elements of Set 2 (space-separated): 3 4 5 6 7
#
# Set 1: {1, 2, 3, 4, 5}
# Set 2: {3, 4, 5, 6, 7}
#
# =======================================================
#    RESULTS OF SET OPERATIONS
# =======================================================
# Union                          : {1, 2, 3, 4, 5, 6, 7}
# Intersection                   : {3, 4, 5}
# Difference (Set1 - Set2)       : {1, 2}
# Difference (Set2 - Set1)       : {6, 7}
# Symmetric Difference           : {1, 2, 6, 7}
# Is Set1 subset of Set2         : False
# Is Set2 subset of Set1         : False
# Is Set1 superset of Set2       : False
# Is Set2 superset of Set1       : False
