# Q33. Create a program that copies contents from one file to another and displays
# the total number of words copied.

def create_source_file(filename):
    """Create a sample source file for demonstration."""
    content = """Python is a high-level, general-purpose programming language.
Its design philosophy emphasizes code readability with the use of significant indentation.
Python is dynamically typed and garbage-collected.
It supports multiple programming paradigms, including structured, object-oriented and functional programming.
Python was conceived in the late 1980s by Guido van Rossum.
It is one of the most popular programming languages in the world today."""

    with open(filename, 'w') as f:
        f.write(content)
    print(f"✅ Source file '{filename}' created successfully!")


def copy_file_contents(source_file, destination_file):
    """Copy contents from source file to destination file and count words."""
    try:
        # Read from source file
        with open(source_file, 'r') as src:
            content = src.read()

        # Write to destination file
        with open(destination_file, 'w') as dest:
            dest.write(content)

        # Count words, lines, and characters
        words = content.split()
        lines = content.split('\n')

        word_count = len(words)
        line_count = len(lines)
        char_count = len(content)

        # Display results
        print("\n" + "=" * 55)
        print("   FILE COPY REPORT")
        print("=" * 55)
        print(f"   Source File      : {source_file}")
        print(f"   Destination File : {destination_file}")
        print("-" * 55)
        print(f"   Words Copied     : {word_count}")
        print(f"   Lines Copied     : {line_count}")
        print(f"   Characters Copied: {char_count}")
        print("=" * 55)
        print(f"\n   ✅ File copied successfully!")

        # Display copied content
        print(f"\n📄 Copied Content:")
        print("-" * 55)
        for i, line in enumerate(lines, 1):
            print(f"  {i:>3} | {line}")
        print("-" * 55)

        return word_count

    except FileNotFoundError:
        print(f"\n❌ FileNotFoundError: Source file '{source_file}' not found!")
        return 0
    except PermissionError:
        print(f"\n❌ PermissionError: No permission to access the file!")
        return 0
    except IOError as e:
        print(f"\n❌ IOError: {e}")
        return 0


def verify_copy(source_file, destination_file):
    """Verify that the copy was successful."""
    try:
        with open(source_file, 'r') as src:
            source_content = src.read()
        with open(destination_file, 'r') as dest:
            dest_content = dest.read()

        if source_content == dest_content:
            print("\n✅ Verification: Files match perfectly!")
        else:
            print("\n❌ Verification: Files do NOT match!")
    except FileNotFoundError as e:
        print(f"\n❌ Verification failed: {e}")


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   FILE COPY PROGRAM")
    print("=" * 55)

    print("\n1. Create sample file and copy")
    print("2. Copy an existing file")
    choice = input("\nEnter your choice (1/2): ")

    if choice == '1':
        source = "source_file.txt"
        destination = "copied_file.txt"
        create_source_file(source)
        word_count = copy_file_contents(source, destination)
        verify_copy(source, destination)
    elif choice == '2':
        source = input("Enter source filename: ").strip()
        destination = input("Enter destination filename: ").strip()
        word_count = copy_file_contents(source, destination)
        if word_count > 0:
            verify_copy(source, destination)
    else:
        print("❌ Invalid choice!")


# Expected Output:
# =======================================================
#    FILE COPY PROGRAM
# =======================================================
#
# 1. Create sample file and copy
# 2. Copy an existing file
#
# Enter your choice (1/2): 1
# ✅ Source file 'source_file.txt' created successfully!
#
# =======================================================
#    FILE COPY REPORT
# =======================================================
#    Source File      : source_file.txt
#    Destination File : copied_file.txt
# -------------------------------------------------------
#    Words Copied     : 62
#    Lines Copied     : 6
#    Characters Copied: 410
# =======================================================
#
#    ✅ File copied successfully!
#
# ✅ Verification: Files match perfectly!
