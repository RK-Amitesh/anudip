# Q18. Develop a frequency counter that stores occurrences of each word from a paragraph
# into a dictionary and displays the most/least used words.

def count_word_frequency(paragraph):
    """Count the frequency of each word in the paragraph."""
    # Clean the paragraph: convert to lowercase and remove punctuation
    import string
    cleaned = paragraph.lower()
    cleaned = cleaned.translate(str.maketrans('', '', string.punctuation))

    # Split into words
    words = cleaned.split()

    # Count frequency using dictionary
    frequency = {}
    for word in words:
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1

    return frequency


def display_frequency(frequency):
    """Display word frequency in a formatted table."""
    # Sort by frequency (descending)
    sorted_freq = sorted(frequency.items(), key=lambda x: x[1], reverse=True)

    print(f"\n{'Word':<20} {'Frequency':>10} {'Bar Chart'}")
    print("-" * 55)
    for word, count in sorted_freq:
        bar = "█" * count
        print(f"{word:<20} {count:>10}  {bar}")
    print("-" * 55)
    print(f"{'Total unique words':<20} {len(frequency):>10}")
    total_words = sum(frequency.values())
    print(f"{'Total words':<20} {total_words:>10}")


def get_most_least_used(frequency):
    """Find the most and least used words."""
    max_count = max(frequency.values())
    min_count = min(frequency.values())

    most_used = [word for word, count in frequency.items() if count == max_count]
    least_used = [word for word, count in frequency.items() if count == min_count]

    return most_used, max_count, least_used, min_count


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   WORD FREQUENCY COUNTER")
    print("=" * 55)

    # Accept paragraph from user
    paragraph = input("\nEnter a paragraph:\n")

    # Count word frequency
    frequency = count_word_frequency(paragraph)

    # Display frequency table
    print("\n" + "=" * 55)
    print("   WORD FREQUENCY TABLE")
    print("=" * 55)
    display_frequency(frequency)

    # Find most and least used words
    most_used, max_count, least_used, min_count = get_most_least_used(frequency)

    print(f"\n🔝 Most Used Word(s) (appeared {max_count} times):")
    for word in most_used:
        print(f"   - '{word}'")

    print(f"\n🔻 Least Used Word(s) (appeared {min_count} time(s)):")
    for word in least_used:
        print(f"   - '{word}'")


# Expected Output:
# =======================================================
#    WORD FREQUENCY COUNTER
# =======================================================
#
# Enter a paragraph:
# Python is a great programming language. Python is easy to learn.
# Python is used for web development, data science, and AI.
#
# =======================================================
#    WORD FREQUENCY TABLE
# =======================================================
#
# Word                 Frequency  Bar Chart
# -------------------------------------------------------
# python                       3  ███
# is                           3  ███
# a                            2  ██
# to                           1  █
# great                        1  █
# ...
# -------------------------------------------------------
# Total unique words          15
# Total words                 21
#
# 🔝 Most Used Word(s) (appeared 3 times):
#    - 'python'
#    - 'is'
#
# 🔻 Least Used Word(s) (appeared 1 time(s)):
#    - 'great'
#    - 'programming'
#    ...
