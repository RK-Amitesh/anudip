# Q34. Write a program to encrypt a message using Caesar Cipher technique
# and decrypt it back to the original text.

def caesar_encrypt(message, shift):
    """Encrypt a message using Caesar Cipher."""
    encrypted = ""

    for char in message:
        if char.isupper():
            # Encrypt uppercase letters
            encrypted += chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
        elif char.islower():
            # Encrypt lowercase letters
            encrypted += chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
        else:
            # Keep non-alphabetic characters unchanged
            encrypted += char

    return encrypted


def caesar_decrypt(encrypted_message, shift):
    """Decrypt a Caesar Cipher message."""
    # Decryption is just encryption with negative shift
    return caesar_encrypt(encrypted_message, -shift)


def brute_force_decrypt(encrypted_message):
    """Try all 26 possible shifts to decrypt."""
    print("\n🔓 Brute Force Decryption (All 26 shifts):")
    print("-" * 50)
    results = []
    for shift in range(26):
        decrypted = caesar_decrypt(encrypted_message, shift)
        results.append((shift, decrypted))
        print(f"   Shift {shift:>2}: {decrypted}")
    return results


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   🔐 CAESAR CIPHER ENCRYPTION/DECRYPTION")
    print("=" * 55)

    while True:
        print("\n--- MENU ---")
        print("1. Encrypt a message")
        print("2. Decrypt a message")
        print("3. Encrypt & Decrypt (Demo)")
        print("4. Brute Force Decrypt")
        print("5. Exit")
        print("-" * 25)

        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            message = input("\nEnter message to encrypt: ")
            shift = int(input("Enter shift value (1-25): "))
            encrypted = caesar_encrypt(message, shift)
            print(f"\n🔒 Encrypted Message: {encrypted}")

        elif choice == '2':
            message = input("\nEnter message to decrypt: ")
            shift = int(input("Enter shift value used for encryption: "))
            decrypted = caesar_decrypt(message, shift)
            print(f"\n🔓 Decrypted Message: {decrypted}")

        elif choice == '3':
            message = input("\nEnter a message: ")
            shift = int(input("Enter shift value (1-25): "))

            # Encrypt
            encrypted = caesar_encrypt(message, shift)

            # Decrypt
            decrypted = caesar_decrypt(encrypted, shift)

            # Display results
            print("\n" + "=" * 55)
            print("   CAESAR CIPHER DEMO")
            print("=" * 55)
            print(f"   Original Message  : {message}")
            print(f"   Shift Value       : {shift}")
            print(f"   🔒 Encrypted      : {encrypted}")
            print(f"   🔓 Decrypted      : {decrypted}")
            print("=" * 55)

            # Verify
            if message == decrypted:
                print("   ✅ Verification: Original and decrypted messages match!")
            else:
                print("   ❌ Verification: Messages do NOT match!")

        elif choice == '4':
            message = input("\nEnter encrypted message: ")
            brute_force_decrypt(message)

        elif choice == '5':
            print("\n👋 Goodbye!")
            break

        else:
            print("❌ Invalid choice!")


# Expected Output:
# =======================================================
#    🔐 CAESAR CIPHER ENCRYPTION/DECRYPTION
# =======================================================
#
# --- MENU ---
# 1. Encrypt a message
# 2. Decrypt a message
# 3. Encrypt & Decrypt (Demo)
# 4. Brute Force Decrypt
# 5. Exit
# -------------------------
# Enter your choice (1-5): 3
#
# Enter a message: Hello World Python
# Enter shift value (1-25): 3
#
# =======================================================
#    CAESAR CIPHER DEMO
# =======================================================
#    Original Message  : Hello World Python
#    Shift Value       : 3
#    🔒 Encrypted      : Khoor Zruog Sbwkrq
#    🔓 Decrypted      : Hello World Python
# =======================================================
#    ✅ Verification: Original and decrypted messages match!
