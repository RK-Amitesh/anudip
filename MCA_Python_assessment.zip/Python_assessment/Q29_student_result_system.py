# Q29. Create a classroom student seating system involving multiple subjects.
# Calculate total marks, percentage, and assign grades using if conditions.

def get_grade(percentage):
    """Assign grade based on percentage using if conditions."""
    if percentage >= 90:
        return 'A+', 'Outstanding'
    elif percentage >= 80:
        return 'A', 'Excellent'
    elif percentage >= 70:
        return 'B+', 'Very Good'
    elif percentage >= 60:
        return 'B', 'Good'
    elif percentage >= 50:
        return 'C', 'Average'
    elif percentage >= 40:
        return 'D', 'Pass'
    else:
        return 'F', 'Fail'


# Main program
if __name__ == "__main__":
    print("=" * 65)
    print("   CLASSROOM STUDENT RESULT MANAGEMENT SYSTEM")
    print("=" * 65)

    # Define subjects
    subjects = ['Mathematics', 'Science', 'English', 'Hindi', 'Computer Science']
    max_marks_per_subject = 100

    # Accept number of students
    n = int(input("\nEnter the number of students: "))

    students_data = []

    # Input student data
    for i in range(n):
        print(f"\n{'='*40}")
        print(f"   Student {i + 1}")
        print(f"{'='*40}")

        name = input("Enter student name: ").strip()
        roll_no = input("Enter roll number: ").strip()

        marks = {}
        print(f"\nEnter marks for {name} (out of {max_marks_per_subject}):")
        for subject in subjects:
            while True:
                try:
                    mark = float(input(f"  {subject}: "))
                    if 0 <= mark <= max_marks_per_subject:
                        marks[subject] = mark
                        break
                    else:
                        print(f"  ❌ Marks must be between 0 and {max_marks_per_subject}")
                except ValueError:
                    print("  ❌ Please enter a valid number!")

        # Calculate total and percentage
        total = sum(marks.values())
        max_total = len(subjects) * max_marks_per_subject
        percentage = (total / max_total) * 100
        grade, remark = get_grade(percentage)

        # Check if failed in any subject (below 33)
        failed_subjects = [sub for sub, mark in marks.items() if mark < 33]

        student_record = {
            'name': name,
            'roll_no': roll_no,
            'marks': marks,
            'total': total,
            'percentage': percentage,
            'grade': grade,
            'remark': remark,
            'failed_subjects': failed_subjects,
            'status': 'FAIL' if failed_subjects or percentage < 40 else 'PASS'
        }
        students_data.append(student_record)

    # Display Results
    print("\n" + "=" * 90)
    print("   📋 STUDENT RESULT REPORT CARD")
    print("=" * 90)

    for student in students_data:
        print(f"\n{'─'*60}")
        print(f"  Name: {student['name']}  |  Roll No: {student['roll_no']}")
        print(f"{'─'*60}")

        print(f"  {'Subject':<25} {'Marks':>8} {'Status':>10}")
        print(f"  {'-'*48}")
        for subject, mark in student['marks'].items():
            status = "✅ Pass" if mark >= 33 else "❌ Fail"
            print(f"  {subject:<25} {mark:>8.1f} {status:>10}")

        print(f"  {'-'*48}")
        print(f"  {'Total':<25} {student['total']:>8.1f} / {len(subjects) * max_marks_per_subject}")
        print(f"  {'Percentage':<25} {student['percentage']:>8.2f}%")
        print(f"  {'Grade':<25} {student['grade']:>8}")
        print(f"  {'Remark':<25} {student['remark']:>8}")
        print(f"  {'Result':<25} {student['status']:>8}")

        if student['failed_subjects']:
            print(f"  ⚠️  Failed in: {', '.join(student['failed_subjects'])}")

    # Class Summary
    print("\n" + "=" * 65)
    print("   📊 CLASS SUMMARY")
    print("=" * 65)

    all_percentages = [s['percentage'] for s in students_data]
    passed = sum(1 for s in students_data if s['status'] == 'PASS')
    failed = len(students_data) - passed

    print(f"   Total Students  : {len(students_data)}")
    print(f"   Class Average   : {sum(all_percentages) / len(all_percentages):.2f}%")
    print(f"   Highest Marks   : {max(all_percentages):.2f}% ({[s['name'] for s in students_data if s['percentage'] == max(all_percentages)][0]})")
    print(f"   Lowest Marks    : {min(all_percentages):.2f}%")
    print(f"   Passed          : {passed}")
    print(f"   Failed          : {failed}")
    print(f"   Pass Rate       : {(passed / len(students_data)) * 100:.2f}%")


# Expected Output:
# =================================================================
#    CLASSROOM STUDENT RESULT MANAGEMENT SYSTEM
# =================================================================
#
# Enter the number of students: 3
# (Enter student names and marks for each subject)
#
# =================================================================
#    📋 STUDENT RESULT REPORT CARD
# =================================================================
#
# ────────────────────────────────────────────────────────────
#   Name: Rahul  |  Roll No: 101
# ────────────────────────────────────────────────────────────
#   Subject                     Marks     Status
#   ------------------------------------------------
#   Mathematics                  85.0    ✅ Pass
#   Science                      72.0    ✅ Pass
#   English                      68.0    ✅ Pass
#   Hindi                        90.0    ✅ Pass
#   Computer Science             88.0    ✅ Pass
#   ------------------------------------------------
#   Total                       403.0 / 500
#   Percentage                  80.60%
#   Grade                           A
#   Remark                  Excellent
#   Result                      PASS
