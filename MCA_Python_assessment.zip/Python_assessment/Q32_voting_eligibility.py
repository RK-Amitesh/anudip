# Q32. Write a Python program that validates user age for voting eligibility
# and handles invalid model/system errors and exceptions.

def validate_voting_eligibility():
    """Validate user age for voting eligibility with exception handling."""
    print("=" * 50)
    print("   🗳️  VOTING ELIGIBILITY CHECKER")
    print("=" * 50)

    max_attempts = 3
    attempt = 0

    while attempt < max_attempts:
        try:
            # Accept user input
            name = input("\nEnter your name: ").strip()

            if not name:
                raise ValueError("Name cannot be empty!")

            if not name.replace(" ", "").isalpha():
                raise ValueError("Name should contain only alphabets!")

            # Accept age
            age_input = input("Enter your age: ")

            # Check if input is numeric
            if not age_input.strip():
                raise ValueError("Age cannot be empty!")

            age = int(age_input)

            # Validate age range
            if age < 0:
                raise ValueError("Age cannot be negative!")
            elif age > 150:
                raise ValueError("Age seems unrealistic! Please enter a valid age.")
            elif age == 0:
                raise ValueError("Age cannot be zero!")

            # Check voting eligibility
            print("\n" + "-" * 40)
            print(f"   Name: {name}")
            print(f"   Age : {age}")
            print("-" * 40)

            if age >= 18:
                print(f"\n   ✅ Congratulations {name}!")
                print(f"   You are ELIGIBLE to vote. 🗳️")

                if age >= 18 and age <= 25:
                    print("   📌 Note: As a young voter, your vote matters a lot!")
                elif age >= 60:
                    print("   📌 Note: Senior citizens can avail priority voting facilities.")
            else:
                years_left = 18 - age
                print(f"\n   ❌ Sorry {name}!")
                print(f"   You are NOT eligible to vote yet.")
                print(f"   📌 You need to wait {years_left} more year(s).")
                print(f"   📌 You will be eligible in {2025 + years_left}.")

            # Successful validation, exit loop
            break

        except ValueError as e:
            attempt += 1
            print(f"\n   ❌ ValueError: {e}")
            if attempt < max_attempts:
                print(f"   ⚠️  Attempts remaining: {max_attempts - attempt}")
            else:
                print("   🚫 Maximum attempts reached!")

        except TypeError as e:
            attempt += 1
            print(f"\n   ❌ TypeError: {e}")

        except OverflowError:
            attempt += 1
            print("\n   ❌ OverflowError: Number is too large!")

        except KeyboardInterrupt:
            print("\n\n   ⚠️  Program interrupted by user.")
            break

        except Exception as e:
            attempt += 1
            print(f"\n   ❌ Unexpected Error: {type(e).__name__}: {e}")

        finally:
            if attempt >= max_attempts:
                print("\n" + "=" * 50)
                print("   Program terminated after maximum attempts.")
                print("=" * 50)


# Main program
if __name__ == "__main__":
    validate_voting_eligibility()


# Expected Output:
# ==================================================
#    🗳️  VOTING ELIGIBILITY CHECKER
# ==================================================
#
# Enter your name: Rahul Sharma
# Enter your age: 21
#
# ----------------------------------------
#    Name: Rahul Sharma
#    Age : 21
# ----------------------------------------
#
#    ✅ Congratulations Rahul Sharma!
#    You are ELIGIBLE to vote. 🗳️
#    📌 Note: As a young voter, your vote matters a lot!
#
# --- OR ---
#
# Enter your name: Priya
# Enter your age: 15
#
# ----------------------------------------
#    Name: Priya
#    Age : 15
# ----------------------------------------
#
#    ❌ Sorry Priya!
#    You are NOT eligible to vote yet.
#    📌 You need to wait 3 more year(s).
#    📌 You will be eligible in 2028.
