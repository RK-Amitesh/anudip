# Q11. Create a file for storing student marks. Read the file and display the topper,
# average marks, and students scoring below average.

def create_student_file(filename):
    """Create a file with student marks data."""
    students = []
    n = int(input("Enter the number of students: "))

    for i in range(n):
        print(f"\n--- Student {i + 1} ---")
        name = input("Enter student name: ").strip()
        marks = float(input("Enter marks (out of 100): "))
        students.append((name, marks))

    # Write to file
    with open(filename, 'w') as f:
        f.write("Name,Marks\n")  # Header
        for name, marks in students:
            f.write(f"{name},{marks}\n")

    print(f"\n✅ Student data saved to '{filename}'")
    return students


def read_student_file(filename):
    """Read student data from file."""
    students = []
    try:
        with open(filename, 'r') as f:
            lines = f.readlines()
            for line in lines[1:]:  # Skip header
                parts = line.strip().split(',')
                if len(parts) == 2:
                    name = parts[0]
                    marks = float(parts[1])
                    students.append((name, marks))
    except FileNotFoundError:
        print(f"❌ File '{filename}' not found!")
    return students


def analyze_student_data(students):
    """Analyze student data - find topper, average, below average students."""
    if not students:
        print("❌ No student data to analyze!")
        return

    # Find topper (student with highest marks)
    topper = max(students, key=lambda x: x[1])

    # Calculate average marks
    total_marks = sum(marks for _, marks in students)
    average_marks = total_marks / len(students)

    # Find students below average
    below_average = [(name, marks) for name, marks in students if marks < average_marks]

    # Display results
    print("\n" + "=" * 50)
    print("   STUDENT MARKS ANALYSIS REPORT")
    print("=" * 50)

    # Display all students
    print(f"\n{'Name':<25} {'Marks':>10}")
    print("-" * 40)
    for name, marks in students:
        print(f"{name:<25} {marks:>10.2f}")
    print("-" * 40)

    # Display topper
    print(f"\n🏆 Topper: {topper[0]} with {topper[1]:.2f} marks")

    # Display average
    print(f"\n📊 Average Marks: {average_marks:.2f}")

    # Display below average students
    print(f"\n📉 Students Below Average ({average_marks:.2f}):")
    if below_average:
        for name, marks in below_average:
            print(f"   - {name}: {marks:.2f}")
    else:
        print("   None! All students are above average.")


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   STUDENT MARKS MANAGEMENT SYSTEM")
    print("=" * 50)

    filename = "student_marks.txt"

    print("\n1. Create new student data file")
    print("2. Read existing file and analyze")
    choice = input("\nEnter your choice (1/2): ")

    if choice == '1':
        # Create file and analyze
        students = create_student_file(filename)
        analyze_student_data(students)
    elif choice == '2':
        # Read from existing file and analyze
        students = read_student_file(filename)
        analyze_student_data(students)
    else:
        print("❌ Invalid choice!")


# Expected Output:
# ==================================================
#    STUDENT MARKS MANAGEMENT SYSTEM
# ==================================================
#
# 1. Create new student data file
# 2. Read existing file and analyze
#
# Enter your choice (1/2): 1
# Enter the number of students: 5
#
# --- Student 1 ---
# Enter student name: Rahul
# Enter marks (out of 100): 85
#
# --- Student 2 ---
# Enter student name: Priya
# Enter marks (out of 100): 92
#
# --- Student 3 ---
# Enter student name: Amit
# Enter marks (out of 100): 67
#
# --- Student 4 ---
# Enter student name: Sneha
# Enter marks (out of 100): 78
#
# --- Student 5 ---
# Enter student name: Rohan
# Enter marks (out of 100): 55
#
# ✅ Student data saved to 'student_marks.txt'
#
# ==================================================
#    STUDENT MARKS ANALYSIS REPORT
# ==================================================
#
# Name                       Marks
# ----------------------------------------
# Rahul                      85.00
# Priya                      92.00
# Amit                       67.00
# Sneha                      78.00
# Rohan                      55.00
# ----------------------------------------
#
# 🏆 Topper: Priya with 92.00 marks
#
# 📊 Average Marks: 75.40
#
# 📉 Students Below Average (75.40):
#    - Amit: 67.00
#    - Rohan: 55.00
