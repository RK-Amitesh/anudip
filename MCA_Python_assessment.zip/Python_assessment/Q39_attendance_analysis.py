# Q39. Read a CSV file containing student attendance records and display students
# with attendance below 75%.

import pandas as pd


def create_attendance_csv(filename):
    """Create a sample attendance CSV file."""
    data = {
        'Roll_No': [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
        'Name': ['Rahul Sharma', 'Priya Singh', 'Amit Kumar', 'Sneha Patel', 'Rohan Verma',
                 'Kavita Joshi', 'Deepak Gupta', 'Anita Reddy', 'Suresh Nair', 'Meera Das'],
        'Total_Classes': [120, 120, 120, 120, 120, 120, 120, 120, 120, 120],
        'Classes_Attended': [110, 85, 96, 70, 115, 60, 105, 78, 92, 55]
    }

    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"✅ Attendance CSV file '{filename}' created successfully!")
    return df


def analyze_attendance(filename):
    """Read attendance CSV and display students below 75%."""
    try:
        # Read CSV file
        df = pd.read_csv(filename)

        # Calculate attendance percentage
        df['Attendance_%'] = (df['Classes_Attended'] / df['Total_Classes'] * 100).round(2)

        # Determine status
        df['Status'] = df['Attendance_%'].apply(
            lambda x: '✅ Eligible' if x >= 75 else '❌ Not Eligible'
        )

        # Display all student attendance
        print("\n" + "=" * 75)
        print("   ALL STUDENT ATTENDANCE RECORDS")
        print("=" * 75)
        print(df.to_string(index=False))

        # Filter students below 75%
        below_75 = df[df['Attendance_%'] < 75]

        print("\n" + "=" * 75)
        print("   ⚠️  STUDENTS WITH ATTENDANCE BELOW 75%")
        print("=" * 75)

        if not below_75.empty:
            print(f"\n{'Roll No':<10} {'Name':<20} {'Attended':<12} {'Total':<10} {'%':>8} {'Shortage':>10}")
            print("-" * 75)
            for _, student in below_75.iterrows():
                shortage = int(0.75 * student['Total_Classes']) - student['Classes_Attended']
                if shortage < 0:
                    shortage = 0
                print(f"{student['Roll_No']:<10} {student['Name']:<20} "
                      f"{student['Classes_Attended']:<12} {student['Total_Classes']:<10} "
                      f"{student['Attendance_%']:>7.2f}% {shortage:>10}")
            print("-" * 75)
            print(f"\nTotal students below 75%: {len(below_75)} out of {len(df)}")
        else:
            print("\n✅ All students have attendance above 75%!")

        # Class statistics
        print("\n" + "=" * 75)
        print("   📊 CLASS ATTENDANCE STATISTICS")
        print("=" * 75)
        print(f"   Total Students           : {len(df)}")
        print(f"   Average Attendance       : {df['Attendance_%'].mean():.2f}%")
        print(f"   Highest Attendance       : {df['Attendance_%'].max():.2f}% ({df.loc[df['Attendance_%'].idxmax(), 'Name']})")
        print(f"   Lowest Attendance        : {df['Attendance_%'].min():.2f}% ({df.loc[df['Attendance_%'].idxmin(), 'Name']})")
        print(f"   Students >= 75%          : {len(df[df['Attendance_%'] >= 75])}")
        print(f"   Students < 75% (Detained): {len(below_75)}")

    except FileNotFoundError:
        print(f"❌ File '{filename}' not found!")
    except Exception as e:
        print(f"❌ Error: {e}")


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   📋 STUDENT ATTENDANCE MANAGEMENT SYSTEM")
    print("=" * 55)

    filename = "student_attendance.csv"

    print("\n1. Create sample CSV and analyze")
    print("2. Analyze existing CSV file")
    choice = input("\nEnter your choice (1/2): ")

    if choice == '1':
        create_attendance_csv(filename)
        analyze_attendance(filename)
    elif choice == '2':
        csv_file = input("Enter CSV filename: ").strip()
        analyze_attendance(csv_file)
    else:
        print("❌ Invalid choice!")


# Expected Output:
# =======================================================
#    📋 STUDENT ATTENDANCE MANAGEMENT SYSTEM
# =======================================================
#
# ✅ Attendance CSV file 'student_attendance.csv' created!
#
# ===========================================================================
#    ALL STUDENT ATTENDANCE RECORDS
# ===========================================================================
# Roll_No          Name  Total_Classes  Classes_Attended  Attendance_%         Status
#     101  Rahul Sharma            120               110         91.67    ✅ Eligible
#     102   Priya Singh            120                85         70.83  ❌ Not Eligible
#     ...
#
# ===========================================================================
#    ⚠️  STUDENTS WITH ATTENDANCE BELOW 75%
# ===========================================================================
# Roll No   Name                 Attended     Total         %    Shortage
# ---------------------------------------------------------------------------
# 102       Priya Singh          85           120       70.83%          5
# 104       Sneha Patel          70           120       58.33%         20
# 106       Kavita Joshi         60           120       50.00%         30
# 108       Anita Reddy          78           120       65.00%         12
# 110       Meera Das            55           120       45.83%         35
# ---------------------------------------------------------------------------
# Total students below 75%: 5 out of 10
