# Q40. Design a mini student management system using functions, dictionaries,
# file handling, exception handling, and Pandas for report generation.

import os
import pandas as pd
from datetime import datetime


# ==================== DATA STORAGE ====================
STUDENT_FILE = "students_database.csv"


def load_students():
    """Load students from CSV file."""
    try:
        if os.path.exists(STUDENT_FILE):
            df = pd.read_csv(STUDENT_FILE)
            return df.to_dict('records')
        return []
    except Exception as e:
        print(f"❌ Error loading data: {e}")
        return []


def save_students(students):
    """Save students to CSV file."""
    try:
        df = pd.DataFrame(students)
        df.to_csv(STUDENT_FILE, index=False)
    except Exception as e:
        print(f"❌ Error saving data: {e}")


# ==================== STUDENT OPERATIONS ====================
def add_student(students):
    """Add a new student record."""
    try:
        print("\n--- Add New Student ---")
        roll_no = input("Enter Roll Number: ").strip()

        # Check for duplicate roll number
        for student in students:
            if str(student['Roll_No']) == roll_no:
                print(f"❌ Roll number {roll_no} already exists!")
                return

        name = input("Enter Name: ").strip().title()
        age = int(input("Enter Age: "))

        if age < 5 or age > 30:
            raise ValueError("Age must be between 5 and 30!")

        course = input("Enter Course (MCA/BCA/B.Tech): ").strip().upper()

        # Enter marks for subjects
        subjects = ['Mathematics', 'Science', 'English', 'Programming', 'Database']
        marks = {}
        print(f"\nEnter marks for {name} (out of 100):")
        for subject in subjects:
            while True:
                try:
                    mark = float(input(f"  {subject}: "))
                    if 0 <= mark <= 100:
                        marks[subject] = mark
                        break
                    else:
                        print("  ❌ Marks must be between 0 and 100!")
                except ValueError:
                    print("  ❌ Enter a valid number!")

        # Calculate total, percentage, and grade
        total = sum(marks.values())
        percentage = (total / (len(subjects) * 100)) * 100
        grade = get_grade(percentage)

        student_record = {
            'Roll_No': roll_no,
            'Name': name,
            'Age': age,
            'Course': course,
            'Mathematics': marks['Mathematics'],
            'Science': marks['Science'],
            'English': marks['English'],
            'Programming': marks['Programming'],
            'Database': marks['Database'],
            'Total': total,
            'Percentage': round(percentage, 2),
            'Grade': grade,
            'Date_Added': datetime.now().strftime("%Y-%m-%d")
        }

        students.append(student_record)
        save_students(students)
        print(f"\n✅ Student '{name}' (Roll No: {roll_no}) added successfully!")

    except ValueError as e:
        print(f"❌ ValueError: {e}")
    except Exception as e:
        print(f"❌ Error: {e}")


def get_grade(percentage):
    """Assign grade based on percentage."""
    if percentage >= 90: return 'A+'
    elif percentage >= 80: return 'A'
    elif percentage >= 70: return 'B+'
    elif percentage >= 60: return 'B'
    elif percentage >= 50: return 'C'
    elif percentage >= 40: return 'D'
    else: return 'F'


def view_all_students(students):
    """Display all student records."""
    if not students:
        print("\n📋 No students found!")
        return

    df = pd.DataFrame(students)
    print("\n" + "=" * 80)
    print("   ALL STUDENT RECORDS")
    print("=" * 80)
    display_cols = ['Roll_No', 'Name', 'Course', 'Total', 'Percentage', 'Grade']
    print(df[display_cols].to_string(index=False))
    print("-" * 80)
    print(f"Total Students: {len(students)}")


def search_student(students):
    """Search for a student by roll number or name."""
    search_term = input("\nEnter Roll Number or Name to search: ").strip()

    found = []
    for student in students:
        if (str(student['Roll_No']) == search_term or
                search_term.lower() in student['Name'].lower()):
            found.append(student)

    if found:
        for s in found:
            print(f"\n{'─' * 40}")
            print(f"  📋 STUDENT DETAILS")
            print(f"{'─' * 40}")
            for key, value in s.items():
                print(f"  {key:<15}: {value}")
    else:
        print(f"❌ No student found matching '{search_term}'!")


def update_student(students):
    """Update student marks."""
    roll_no = input("\nEnter Roll Number to update: ").strip()

    for student in students:
        if str(student['Roll_No']) == roll_no:
            print(f"\nUpdating marks for {student['Name']}:")
            subjects = ['Mathematics', 'Science', 'English', 'Programming', 'Database']

            for subject in subjects:
                try:
                    new_mark = input(f"  {subject} [{student[subject]}]: ").strip()
                    if new_mark:
                        mark = float(new_mark)
                        if 0 <= mark <= 100:
                            student[subject] = mark
                        else:
                            print("  ❌ Invalid! Keeping old marks.")
                except ValueError:
                    print("  ❌ Invalid! Keeping old marks.")

            # Recalculate total, percentage, grade
            student['Total'] = sum(student[s] for s in subjects)
            student['Percentage'] = round((student['Total'] / 500) * 100, 2)
            student['Grade'] = get_grade(student['Percentage'])

            save_students(students)
            print(f"✅ Student '{student['Name']}' updated successfully!")
            return

    print(f"❌ Student with Roll No '{roll_no}' not found!")


def delete_student(students):
    """Delete a student record."""
    roll_no = input("\nEnter Roll Number to delete: ").strip()

    for i, student in enumerate(students):
        if str(student['Roll_No']) == roll_no:
            confirm = input(f"Delete '{student['Name']}'? (y/n): ")
            if confirm.lower() == 'y':
                students.pop(i)
                save_students(students)
                print(f"✅ Student deleted successfully!")
            else:
                print("❌ Deletion cancelled.")
            return

    print(f"❌ Student with Roll No '{roll_no}' not found!")


def generate_report(students):
    """Generate a detailed class report using Pandas."""
    if not students:
        print("\n📋 No data to generate report!")
        return

    df = pd.DataFrame(students)

    print("\n" + "=" * 70)
    print("   📊 CLASS PERFORMANCE REPORT")
    print("=" * 70)

    # Overall Statistics
    print(f"\n   Total Students      : {len(df)}")
    print(f"   Average Percentage  : {df['Percentage'].mean():.2f}%")
    print(f"   Highest Percentage  : {df['Percentage'].max():.2f}% ({df.loc[df['Percentage'].idxmax(), 'Name']})")
    print(f"   Lowest Percentage   : {df['Percentage'].min():.2f}% ({df.loc[df['Percentage'].idxmin(), 'Name']})")

    # Grade Distribution
    print(f"\n   Grade Distribution:")
    grade_counts = df['Grade'].value_counts()
    for grade, count in grade_counts.items():
        print(f"   Grade {grade}: {count} student(s)")

    # Pass/Fail ratio
    passed = len(df[df['Percentage'] >= 40])
    failed = len(df[df['Percentage'] < 40])
    print(f"\n   Passed: {passed} | Failed: {failed}")
    print(f"   Pass Rate: {(passed / len(df)) * 100:.2f}%")

    # Subject-wise average
    subjects = ['Mathematics', 'Science', 'English', 'Programming', 'Database']
    print(f"\n   Subject-wise Average:")
    for subject in subjects:
        avg = df[subject].mean()
        print(f"   {subject:<15}: {avg:.2f}")

    # Save report to file
    report_file = "class_report.txt"
    with open(report_file, 'w') as f:
        f.write("CLASS PERFORMANCE REPORT\n")
        f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 50 + "\n")
        f.write(df.to_string())
        f.write(f"\n\nAverage Percentage: {df['Percentage'].mean():.2f}%\n")
    print(f"\n   ✅ Report saved to '{report_file}'")


# ==================== MAIN PROGRAM ====================
if __name__ == "__main__":
    print("=" * 55)
    print("   🎓 STUDENT MANAGEMENT SYSTEM")
    print("=" * 55)

    students = load_students()

    while True:
        print("\n--- MAIN MENU ---")
        print("1. Add Student")
        print("2. View All Students")
        print("3. Search Student")
        print("4. Update Student Marks")
        print("5. Delete Student")
        print("6. Generate Class Report")
        print("7. Exit")
        print("-" * 30)

        choice = input("Enter your choice (1-7): ")

        if choice == '1':
            add_student(students)
        elif choice == '2':
            view_all_students(students)
        elif choice == '3':
            search_student(students)
        elif choice == '4':
            update_student(students)
        elif choice == '5':
            delete_student(students)
        elif choice == '6':
            generate_report(students)
        elif choice == '7':
            save_students(students)
            print("\n" + "=" * 55)
            print("   Thank you for using Student Management System! 👋")
            print("=" * 55)
            break
        else:
            print("❌ Invalid choice! Please select 1-7.")


# Expected Output:
# =======================================================
#    🎓 STUDENT MANAGEMENT SYSTEM
# =======================================================
#
# --- MAIN MENU ---
# 1. Add Student
# 2. View All Students
# 3. Search Student
# 4. Update Student Marks
# 5. Delete Student
# 6. Generate Class Report
# 7. Exit
# ------------------------------
# Enter your choice (1-7): 1
#
# --- Add New Student ---
# Enter Roll Number: 101
# Enter Name: Rahul Sharma
# Enter Age: 22
# Enter Course (MCA/BCA/B.Tech): MCA
#
# Enter marks for Rahul Sharma (out of 100):
#   Mathematics: 85
#   Science: 78
#   English: 92
#   Programming: 88
#   Database: 76
#
# ✅ Student 'Rahul Sharma' (Roll No: 101) added successfully!
#
# Enter your choice (1-7): 6
#
# ======================================================================
#    📊 CLASS PERFORMANCE REPORT
# ======================================================================
#    Total Students      : 1
#    Average Percentage  : 83.80%
#    Highest Percentage  : 83.80% (Rahul Sharma)
#    ...
