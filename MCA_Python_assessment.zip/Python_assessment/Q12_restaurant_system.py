# Q12. Develop a restaurant program that handles dictionary/set, invalid inputs,
# and incorrect operations using multiple exception handling.

def display_restaurant_menu(menu):
    """Display the restaurant menu."""
    print(f"\n{'Item':<25} {'Price':>10}")
    print("-" * 40)
    for item, price in menu.items():
        print(f"{item:<25} ₹{price:>9.2f}")
    print("-" * 40)


def add_menu_item(menu):
    """Add a new item to the menu."""
    try:
        item_name = input("Enter item name: ").strip().title()
        if not item_name:
            raise ValueError("Item name cannot be empty!")
        if item_name in menu:
            raise KeyError(f"'{item_name}' already exists in the menu!")
        
        price = float(input(f"Enter price for '{item_name}': ₹"))
        if price <= 0:
            raise ValueError("Price must be a positive number!")
        
        menu[item_name] = price
        print(f"✅ '{item_name}' added to menu at ₹{price:.2f}")
    except ValueError as e:
        print(f"❌ ValueError: {e}")
    except KeyError as e:
        print(f"❌ KeyError: {e}")


def take_order(menu):
    """Take customer order and calculate bill."""
    order = {}
    total = 0.0

    print("\nAvailable Menu:")
    display_restaurant_menu(menu)

    while True:
        try:
            item = input("\nEnter item to order (or 'done' to finish): ").strip().title()

            if item.lower() == 'done':
                break

            if item not in menu:
                raise KeyError(f"'{item}' is not available on the menu!")

            quantity = int(input(f"Enter quantity for '{item}': "))
            if quantity <= 0:
                raise ValueError("Quantity must be a positive integer!")

            if item in order:
                order[item]["quantity"] += quantity
            else:
                order[item] = {"price": menu[item], "quantity": quantity}

            item_total = menu[item] * quantity
            total += item_total
            print(f"✅ Added {quantity}x {item} = ₹{item_total:.2f}")

        except KeyError as e:
            print(f"❌ KeyError: {e}")
        except ValueError as e:
            print(f"❌ ValueError: {e}")
        except Exception as e:
            print(f"❌ Unexpected Error: {e}")

    return order, total


def generate_bill(order, total):
    """Generate and display the bill."""
    if not order:
        print("\n📋 No items ordered!")
        return

    print("\n" + "=" * 55)
    print("          🍽️  RESTAURANT BILL")
    print("=" * 55)
    print(f"{'Item':<20} {'Qty':>5} {'Price':>10} {'Total':>10}")
    print("-" * 55)

    for item, details in order.items():
        item_total = details["price"] * details["quantity"]
        print(f"{item:<20} {details['quantity']:>5} ₹{details['price']:>9.2f} ₹{item_total:>9.2f}")

    print("-" * 55)
    tax = total * 0.05  # 5% GST
    grand_total = total + tax

    print(f"{'Subtotal':<37} ₹{total:>9.2f}")
    print(f"{'GST (5%)':<37} ₹{tax:>9.2f}")
    print(f"{'GRAND TOTAL':<37} ₹{grand_total:>9.2f}")
    print("=" * 55)
    print("     Thank you for dining with us! 🙏")


def remove_menu_item(menu):
    """Remove an item from the menu."""
    try:
        item_name = input("Enter item name to remove: ").strip().title()
        if item_name not in menu:
            raise KeyError(f"'{item_name}' not found in menu!")
        del menu[item_name]
        print(f"✅ '{item_name}' removed from menu.")
    except KeyError as e:
        print(f"❌ KeyError: {e}")


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   🍽️  RESTAURANT MANAGEMENT SYSTEM")
    print("=" * 50)

    # Initial menu using dictionary
    menu = {
        "Butter Chicken": 350.00,
        "Paneer Tikka": 250.00,
        "Dal Makhani": 200.00,
        "Naan": 40.00,
        "Biryani": 300.00,
        "Gulab Jamun": 80.00,
        "Lassi": 60.00
    }

    while True:
        print("\n--- RESTAURANT MENU ---")
        print("1. View Menu")
        print("2. Add Menu Item")
        print("3. Remove Menu Item")
        print("4. Place Order")
        print("5. Exit")
        print("-" * 25)

        try:
            choice = input("Enter your choice (1-5): ")

            if choice == '1':
                display_restaurant_menu(menu)
            elif choice == '2':
                add_menu_item(menu)
            elif choice == '3':
                remove_menu_item(menu)
            elif choice == '4':
                order, total = take_order(menu)
                generate_bill(order, total)
            elif choice == '5':
                print("\n👋 Goodbye! Visit again!")
                break
            else:
                print("❌ Invalid choice! Please select 1-5.")
        except Exception as e:
            print(f"❌ Unexpected Error: {e}")


# Expected Output:
# ==================================================
#    🍽️  RESTAURANT MANAGEMENT SYSTEM
# ==================================================
#
# --- RESTAURANT MENU ---
# 1. View Menu
# 2. Add Menu Item
# 3. Remove Menu Item
# 4. Place Order
# 5. Exit
# -------------------------
# Enter your choice (1-5): 4
#
# Available Menu:
# Item                       Price
# ----------------------------------------
# Butter Chicken           ₹   350.00
# Paneer Tikka             ₹   250.00
# ...
#
# Enter item to order (or 'done' to finish): Butter Chicken
# Enter quantity for 'Butter Chicken': 2
# ✅ Added 2x Butter Chicken = ₹700.00
#
# Enter item to order (or 'done' to finish): done
#
# =======================================================
#           🍽️  RESTAURANT BILL
# =======================================================
# Item                  Qty      Price      Total
# -------------------------------------------------------
# Butter Chicken          2 ₹   350.00 ₹   700.00
# -------------------------------------------------------
# Subtotal                                  ₹   700.00
# GST (5%)                                  ₹    35.00
# GRAND TOTAL                               ₹   735.00
# =======================================================
#      Thank you for dining with us! 🙏
