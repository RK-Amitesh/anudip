# Q16. Write a Python program using functions and loops to generate Fibonacci numbers
# up to N and also display only even Fibonacci numbers in the range.

def generate_fibonacci(n):
    """Generate Fibonacci numbers up to N."""
    fibonacci_series = []
    a, b = 0, 1

    while a <= n:
        fibonacci_series.append(a)
        a, b = b, a + b

    return fibonacci_series


def get_even_fibonacci(fibonacci_series):
    """Filter and return only even Fibonacci numbers."""
    return [num for num in fibonacci_series if num % 2 == 0]


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   FIBONACCI NUMBER GENERATOR")
    print("=" * 50)

    # Accept N from user
    n = int(input("\nEnter the value of N: "))

    if n < 0:
        print("❌ Please enter a non-negative integer!")
    else:
        # Generate Fibonacci numbers up to N
        fib_series = generate_fibonacci(n)

        # Display all Fibonacci numbers
        print(f"\n📊 Fibonacci Numbers up to {n}:")
        print(f"   {fib_series}")
        print(f"   Total Count: {len(fib_series)}")

        # Display even Fibonacci numbers
        even_fib = get_even_fibonacci(fib_series)
        print(f"\n📊 Even Fibonacci Numbers up to {n}:")
        print(f"   {even_fib}")
        print(f"   Total Count: {len(even_fib)}")

        # Display sum of all Fibonacci numbers
        print(f"\n📊 Sum of all Fibonacci numbers: {sum(fib_series)}")
        print(f"📊 Sum of even Fibonacci numbers: {sum(even_fib)}")


# Expected Output:
# ==================================================
#    FIBONACCI NUMBER GENERATOR
# ==================================================
#
# Enter the value of N: 100
#
# 📊 Fibonacci Numbers up to 100:
#    [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
#    Total Count: 12
#
# 📊 Even Fibonacci Numbers up to 100:
#    [0, 2, 8, 34]
#    Total Count: 4
#
# 📊 Sum of all Fibonacci numbers: 232
# 📊 Sum of even Fibonacci numbers: 44
