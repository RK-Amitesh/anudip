# Q35. Develop a contact management system using list and dictionary where users
# can add, update, search, and delete contacts.

def display_menu():
    """Display the contact management menu."""
    print("\n--- CONTACT MANAGEMENT MENU ---")
    print("1. Add Contact")
    print("2. View All Contacts")
    print("3. Search Contact")
    print("4. Update Contact")
    print("5. Delete Contact")
    print("6. Exit")
    print("-" * 35)


def add_contact(contacts):
    """Add a new contact."""
    name = input("Enter name: ").strip().title()

    # Check if contact already exists
    for contact in contacts:
        if contact['name'] == name:
            print(f"❌ Contact '{name}' already exists! Use update option.")
            return

    phone = input("Enter phone number: ").strip()
    email = input("Enter email: ").strip()
    city = input("Enter city: ").strip().title()

    contact = {
        'name': name,
        'phone': phone,
        'email': email,
        'city': city
    }
    contacts.append(contact)
    print(f"✅ Contact '{name}' added successfully!")


def view_all_contacts(contacts):
    """Display all contacts."""
    if not contacts:
        print("\n📋 No contacts found!")
        return

    print(f"\n{'#':<4} {'Name':<20} {'Phone':<15} {'Email':<25} {'City':<15}")
    print("-" * 80)
    for i, contact in enumerate(contacts, 1):
        print(f"{i:<4} {contact['name']:<20} {contact['phone']:<15} {contact['email']:<25} {contact['city']:<15}")
    print("-" * 80)
    print(f"Total Contacts: {len(contacts)}")


def search_contact(contacts):
    """Search for a contact by name or phone."""
    search_term = input("Enter name or phone to search: ").strip()
    found = []

    for contact in contacts:
        if (search_term.lower() in contact['name'].lower() or
                search_term in contact['phone']):
            found.append(contact)

    if found:
        print(f"\n🔍 Found {len(found)} contact(s):")
        for contact in found:
            print(f"\n   📇 Name  : {contact['name']}")
            print(f"   📱 Phone : {contact['phone']}")
            print(f"   📧 Email : {contact['email']}")
            print(f"   🏙️  City  : {contact['city']}")
    else:
        print(f"❌ No contact found matching '{search_term}'!")


def update_contact(contacts):
    """Update an existing contact."""
    name = input("Enter name of contact to update: ").strip().title()

    for contact in contacts:
        if contact['name'] == name:
            print(f"\nCurrent details of '{name}':")
            print(f"   Phone: {contact['phone']}")
            print(f"   Email: {contact['email']}")
            print(f"   City : {contact['city']}")

            print("\nEnter new details (press Enter to keep current):")
            new_phone = input(f"  Phone [{contact['phone']}]: ").strip()
            new_email = input(f"  Email [{contact['email']}]: ").strip()
            new_city = input(f"  City  [{contact['city']}]: ").strip()

            if new_phone:
                contact['phone'] = new_phone
            if new_email:
                contact['email'] = new_email
            if new_city:
                contact['city'] = new_city.title()

            print(f"✅ Contact '{name}' updated successfully!")
            return

    print(f"❌ Contact '{name}' not found!")


def delete_contact(contacts):
    """Delete a contact."""
    name = input("Enter name of contact to delete: ").strip().title()

    for i, contact in enumerate(contacts):
        if contact['name'] == name:
            confirm = input(f"Are you sure you want to delete '{name}'? (y/n): ")
            if confirm.lower() == 'y':
                contacts.pop(i)
                print(f"✅ Contact '{name}' deleted successfully!")
            else:
                print("❌ Deletion cancelled.")
            return

    print(f"❌ Contact '{name}' not found!")


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   📇 CONTACT MANAGEMENT SYSTEM")
    print("=" * 50)

    contacts = []  # List to store contact dictionaries

    while True:
        display_menu()
        choice = input("Enter your choice (1-6): ")

        if choice == '1':
            add_contact(contacts)
        elif choice == '2':
            view_all_contacts(contacts)
        elif choice == '3':
            search_contact(contacts)
        elif choice == '4':
            update_contact(contacts)
        elif choice == '5':
            delete_contact(contacts)
        elif choice == '6':
            print("\n👋 Thank you for using Contact Manager! Goodbye!")
            break
        else:
            print("❌ Invalid choice! Please select 1-6.")


# Expected Output:
# ==================================================
#    📇 CONTACT MANAGEMENT SYSTEM
# ==================================================
#
# --- CONTACT MANAGEMENT MENU ---
# 1. Add Contact
# 2. View All Contacts
# 3. Search Contact
# 4. Update Contact
# 5. Delete Contact
# 6. Exit
# -----------------------------------
# Enter your choice (1-6): 1
# Enter name: Rahul Sharma
# Enter phone number: 9876543210
# Enter email: rahul@gmail.com
# Enter city: Mumbai
# ✅ Contact 'Rahul Sharma' added successfully!
#
# Enter your choice (1-6): 2
# #    Name                 Phone           Email                     City
# --------------------------------------------------------------------------------
# 1    Rahul Sharma         9876543210      rahul@gmail.com           Mumbai
# --------------------------------------------------------------------------------
# Total Contacts: 1
