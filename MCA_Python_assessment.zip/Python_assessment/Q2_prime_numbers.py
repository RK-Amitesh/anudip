# Q2. Develop a program that generates the first 'N' prime numbers using a for loop
# and also calculates the sum and average of those primes.

def is_prime(num):
    """Check if a number is prime."""
    if num < 2:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True


def generate_primes(n):
    """Generate the first N prime numbers."""
    primes = []
    number = 2  # Start checking from 2

    while len(primes) < n:
        if is_prime(number):
            primes.append(number)
        number += 1

    return primes


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   FIRST N PRIME NUMBERS GENERATOR")
    print("=" * 50)

    # Accept N from user
    n = int(input("\nEnter the value of N: "))

    if n <= 0:
        print("Please enter a positive integer!")
    else:
        # Generate first N prime numbers
        primes = generate_primes(n)

        # Calculate sum and average
        prime_sum = sum(primes)
        prime_avg = prime_sum / len(primes)

        # Display results
        print(f"\nFirst {n} Prime Numbers: {primes}")
        print("-" * 40)
        print(f"Sum of first {n} primes  : {prime_sum}")
        print(f"Average of first {n} primes: {prime_avg:.2f}")


# Expected Output:
# ==================================================
#    FIRST N PRIME NUMBERS GENERATOR
# ==================================================
#
# Enter the value of N: 10
#
# First 10 Prime Numbers: [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
# ----------------------------------------
# Sum of first 10 primes  : 129
# Average of first 10 primes: 12.90
