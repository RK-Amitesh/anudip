# Q37. Write a recursive function to calculate the sum of digits of a given number
# and compare it with the iterative version.

import time


def sum_of_digits_recursive(n):
    """Calculate sum of digits using recursion."""
    n = abs(n)  # Handle negative numbers
    if n < 10:
        return n
    return n % 10 + sum_of_digits_recursive(n // 10)


def sum_of_digits_iterative(n):
    """Calculate sum of digits using iteration."""
    n = abs(n)  # Handle negative numbers
    total = 0
    while n > 0:
        total += n % 10
        n //= 10
    return total


def sum_of_digits_string(n):
    """Calculate sum of digits using string conversion."""
    return sum(int(digit) for digit in str(abs(n)))


# Main program
if __name__ == "__main__":
    print("=" * 60)
    print("   SUM OF DIGITS - RECURSIVE vs ITERATIVE")
    print("=" * 60)

    # Accept number from user
    number = int(input("\nEnter a number: "))

    print(f"\nNumber: {number}")
    print(f"Digits: {' + '.join(list(str(abs(number))))}")
    print("-" * 60)

    # Method 1: Recursive
    start = time.perf_counter()
    result_recursive = sum_of_digits_recursive(number)
    time_recursive = time.perf_counter() - start

    # Method 2: Iterative
    start = time.perf_counter()
    result_iterative = sum_of_digits_iterative(number)
    time_iterative = time.perf_counter() - start

    # Method 3: String method
    start = time.perf_counter()
    result_string = sum_of_digits_string(number)
    time_string = time.perf_counter() - start

    # Display results
    print(f"\n{'Method':<25} {'Result':>10} {'Time (μs)':>15}")
    print("-" * 55)
    print(f"{'Recursive':<25} {result_recursive:>10} {time_recursive*1000000:>15.2f}")
    print(f"{'Iterative':<25} {result_iterative:>10} {time_iterative*1000000:>15.2f}")
    print(f"{'String Method':<25} {result_string:>10} {time_string*1000000:>15.2f}")
    print("-" * 55)

    # Verification
    if result_recursive == result_iterative == result_string:
        print(f"\n✅ All methods produce the same result: {result_recursive}")
    else:
        print("\n❌ Results don't match!")

    # Show step-by-step recursive breakdown
    print(f"\n📝 Recursive Breakdown:")
    n = abs(number)
    steps = []
    while n > 0:
        steps.append(str(n % 10))
        n //= 10
    steps.reverse()
    print(f"   {' + '.join(steps)} = {result_recursive}")

    # Comparison
    print(f"\n📊 Performance Comparison:")
    if time_recursive < time_iterative:
        print("   🏆 Recursive method is faster!")
    elif time_iterative < time_recursive:
        print("   🏆 Iterative method is faster!")
    else:
        print("   🤝 Both methods are equally fast!")


# Expected Output:
# ============================================================
#    SUM OF DIGITS - RECURSIVE vs ITERATIVE
# ============================================================
#
# Enter a number: 12345
#
# Number: 12345
# Digits: 1 + 2 + 3 + 4 + 5
# ------------------------------------------------------------
#
# Method                       Result       Time (μs)
# -------------------------------------------------------
# Recursive                        15            2.50
# Iterative                        15            1.80
# String Method                    15            3.20
# -------------------------------------------------------
#
# ✅ All methods produce the same result: 15
#
# 📝 Recursive Breakdown:
#    1 + 2 + 3 + 4 + 5 = 15
#
# 📊 Performance Comparison:
#    🏆 Iterative method is faster!
