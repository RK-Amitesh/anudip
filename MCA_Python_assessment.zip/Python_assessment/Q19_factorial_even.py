# Q19. Write a function that accepts tuples of integers and returns a new list
# containing factorial of only even numbers.

def factorial(n):
    """Calculate factorial of a number."""
    if n == 0 or n == 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


def factorial_of_even_numbers(tuples_data):
    """Accept tuples of integers and return factorials of even numbers only."""
    even_factorials = []

    for num in tuples_data:
        if num % 2 == 0:  # Check if number is even
            fact = factorial(num)
            even_factorials.append((num, fact))

    return even_factorials


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   FACTORIAL OF EVEN NUMBERS FROM TUPLES")
    print("=" * 55)

    # Accept tuple of integers from user
    user_input = input("\nEnter integers separated by spaces: ")
    numbers_tuple = tuple(map(int, user_input.split()))

    print(f"\nInput Tuple: {numbers_tuple}")
    print("-" * 55)

    # Separate even and odd numbers
    even_numbers = [num for num in numbers_tuple if num % 2 == 0]
    odd_numbers = [num for num in numbers_tuple if num % 2 != 0]

    print(f"Even Numbers: {even_numbers}")
    print(f"Odd Numbers : {odd_numbers} (skipped)")

    # Get factorials of even numbers
    result = factorial_of_even_numbers(numbers_tuple)

    # Display results
    print("\n" + "=" * 55)
    print("   FACTORIALS OF EVEN NUMBERS")
    print("=" * 55)

    if result:
        print(f"\n{'Number':>10} {'Factorial':>20}")
        print("-" * 35)
        for num, fact in result:
            print(f"{num:>10} {fact:>20}")

        # Return as a list of factorials
        factorial_list = [fact for _, fact in result]
        print(f"\n📊 Result List (Factorials): {factorial_list}")
    else:
        print("\n❌ No even numbers found in the tuple!")


# Expected Output:
# =======================================================
#    FACTORIAL OF EVEN NUMBERS FROM TUPLES
# =======================================================
#
# Enter integers separated by spaces: 1 2 3 4 5 6 7 8
#
# Input Tuple: (1, 2, 3, 4, 5, 6, 7, 8)
# -------------------------------------------------------
# Even Numbers: [2, 4, 6, 8]
# Odd Numbers : [1, 3, 5, 7] (skipped)
#
# =======================================================
#    FACTORIALS OF EVEN NUMBERS
# =======================================================
#
#     Number            Factorial
# -----------------------------------
#          2                    2
#          4                   24
#          6                  720
#          8                40320
#
# 📊 Result List (Factorials): [2, 24, 720, 40320]
