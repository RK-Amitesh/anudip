# Q28. Develop a menu-driven scientific mathematics utility program using functions
# for factorial, prime checking, and Fibonacci number checking.

def factorial(n):
    """Calculate factorial of a number."""
    if n < 0:
        return "Factorial is not defined for negative numbers!"
    if n == 0 or n == 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


def is_prime(n):
    """Check if a number is prime."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(n ** 0.5) + 1, 2):
        if n % i == 0:
            return False
    return True


def is_fibonacci(n):
    """Check if a number is a Fibonacci number.
    A number is a Fibonacci number if 5*n*n + 4 or 5*n*n - 4 is a perfect square."""
    import math
    if n < 0:
        return False
    check1 = 5 * n * n + 4
    check2 = 5 * n * n - 4
    return (int(math.sqrt(check1)) ** 2 == check1) or (int(math.sqrt(check2)) ** 2 == check2)


def generate_fibonacci_series(n):
    """Generate Fibonacci series up to n terms."""
    series = []
    a, b = 0, 1
    for _ in range(n):
        series.append(a)
        a, b = b, a + b
    return series


def prime_factors(n):
    """Find prime factors of a number."""
    factors = []
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors.append(d)
            n //= d
        d += 1
    if n > 1:
        factors.append(n)
    return factors


def gcd(a, b):
    """Calculate GCD using Euclidean algorithm."""
    while b:
        a, b = b, a % b
    return a


def lcm(a, b):
    """Calculate LCM using GCD."""
    return abs(a * b) // gcd(a, b)


def power(base, exp):
    """Calculate power of a number."""
    return base ** exp


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   🔬 SCIENTIFIC MATHEMATICS UTILITY")
    print("=" * 55)

    while True:
        print("\n--- MENU ---")
        print("1. Factorial")
        print("2. Prime Check")
        print("3. Fibonacci Check")
        print("4. Generate Fibonacci Series")
        print("5. Prime Factors")
        print("6. GCD & LCM")
        print("7. Power Calculator")
        print("8. Exit")
        print("-" * 30)

        choice = input("Enter your choice (1-8): ")

        try:
            if choice == '1':
                n = int(input("\nEnter a number: "))
                result = factorial(n)
                print(f"\n✅ {n}! = {result}")

            elif choice == '2':
                n = int(input("\nEnter a number: "))
                if is_prime(n):
                    print(f"\n✅ {n} IS a prime number!")
                else:
                    print(f"\n❌ {n} is NOT a prime number.")
                    if n > 1:
                        factors = prime_factors(n)
                        print(f"   Factors: {' × '.join(map(str, factors))} = {n}")

            elif choice == '3':
                n = int(input("\nEnter a number: "))
                if is_fibonacci(n):
                    print(f"\n✅ {n} IS a Fibonacci number!")
                else:
                    print(f"\n❌ {n} is NOT a Fibonacci number.")

            elif choice == '4':
                n = int(input("\nEnter number of terms: "))
                series = generate_fibonacci_series(n)
                print(f"\n📊 Fibonacci Series ({n} terms): {series}")
                print(f"   Sum: {sum(series)}")

            elif choice == '5':
                n = int(input("\nEnter a number: "))
                if n <= 1:
                    print("❌ Please enter a number greater than 1!")
                else:
                    factors = prime_factors(n)
                    print(f"\n✅ Prime factors of {n}: {factors}")
                    print(f"   {' × '.join(map(str, factors))} = {n}")

            elif choice == '6':
                a = int(input("\nEnter first number: "))
                b = int(input("Enter second number: "))
                print(f"\n✅ GCD({a}, {b}) = {gcd(a, b)}")
                print(f"✅ LCM({a}, {b}) = {lcm(a, b)}")

            elif choice == '7':
                base = float(input("\nEnter base: "))
                exp = float(input("Enter exponent: "))
                result = power(base, exp)
                print(f"\n✅ {base}^{exp} = {result}")

            elif choice == '8':
                print("\n👋 Goodbye! Happy calculating!")
                break

            else:
                print("❌ Invalid choice! Please select 1-8.")

        except ValueError as e:
            print(f"❌ Invalid input: {e}")
        except Exception as e:
            print(f"❌ Error: {e}")


# Expected Output:
# =======================================================
#    🔬 SCIENTIFIC MATHEMATICS UTILITY
# =======================================================
#
# --- MENU ---
# 1. Factorial
# 2. Prime Check
# 3. Fibonacci Check
# 4. Generate Fibonacci Series
# 5. Prime Factors
# 6. GCD & LCM
# 7. Power Calculator
# 8. Exit
# ------------------------------
# Enter your choice (1-8): 1
# Enter a number: 5
# ✅ 5! = 120
#
# Enter your choice (1-8): 2
# Enter a number: 17
# ✅ 17 IS a prime number!
#
# Enter your choice (1-8): 3
# Enter a number: 13
# ✅ 13 IS a Fibonacci number!
