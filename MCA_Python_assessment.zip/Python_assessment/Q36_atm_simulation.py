# Q36. Create an ATM simulation program that repeatedly asks for PIN validation
# and limits the account after three failed attempts using loops.

def atm_simulation():
    """ATM simulation with PIN validation and account locking."""

    # Predefined accounts (PIN: account details)
    accounts = {
        "1234": {"name": "Rahul Sharma", "balance": 50000.00, "locked": False, "attempts": 0},
        "5678": {"name": "Priya Singh", "balance": 75000.00, "locked": False, "attempts": 0},
        "9012": {"name": "Amit Kumar", "balance": 30000.00, "locked": False, "attempts": 0}
    }

    correct_pin = "1234"  # Default PIN for demo
    max_attempts = 3

    print("=" * 50)
    print("   🏧 ATM SIMULATION SYSTEM")
    print("=" * 50)
    print(f"\n   📌 Demo PIN: {correct_pin}")

    # PIN Validation Loop
    attempts = 0
    authenticated = False

    while attempts < max_attempts:
        pin = input(f"\n   Enter your 4-digit PIN (Attempt {attempts + 1}/{max_attempts}): ")

        # Validate PIN format
        if len(pin) != 4 or not pin.isdigit():
            print("   ❌ Invalid PIN format! PIN must be exactly 4 digits.")
            attempts += 1
            continue

        # Check PIN
        if pin in accounts:
            if accounts[pin]["locked"]:
                print("   🔒 This account is LOCKED! Please visit the bank.")
                return

            accounts[pin]["attempts"] = 0  # Reset attempts on success
            authenticated = True
            current_account = accounts[pin]
            print(f"\n   ✅ Welcome, {current_account['name']}!")
            break
        else:
            attempts += 1
            remaining = max_attempts - attempts
            if remaining > 0:
                print(f"   ❌ Incorrect PIN! {remaining} attempt(s) remaining.")
            else:
                print("   🔒 Account LOCKED after 3 failed attempts!")
                print("   ⚠️  Please visit the nearest bank branch.")
                # Lock the account if it existed
                if correct_pin in accounts:
                    accounts[correct_pin]["locked"] = True
                return

    if not authenticated:
        return

    # ATM Operations Menu
    while True:
        print("\n" + "-" * 40)
        print("   🏧 ATM MENU")
        print("-" * 40)
        print("   1. Check Balance")
        print("   2. Deposit Money")
        print("   3. Withdraw Money")
        print("   4. Mini Statement")
        print("   5. Change PIN")
        print("   6. Exit")
        print("-" * 40)

        choice = input("   Enter your choice (1-6): ")

        if choice == '1':
            # Check Balance
            print(f"\n   💰 Current Balance: ₹{current_account['balance']:.2f}")

        elif choice == '2':
            # Deposit Money
            try:
                amount = float(input("\n   Enter deposit amount: ₹"))
                if amount <= 0:
                    print("   ❌ Amount must be positive!")
                elif amount > 100000:
                    print("   ❌ Maximum deposit limit is ₹1,00,000 per transaction!")
                else:
                    current_account['balance'] += amount
                    print(f"   ✅ ₹{amount:.2f} deposited successfully!")
                    print(f"   💰 New Balance: ₹{current_account['balance']:.2f}")
            except ValueError:
                print("   ❌ Invalid amount!")

        elif choice == '3':
            # Withdraw Money
            try:
                amount = float(input("\n   Enter withdrawal amount: ₹"))
                if amount <= 0:
                    print("   ❌ Amount must be positive!")
                elif amount > current_account['balance']:
                    print(f"   ❌ Insufficient balance! Available: ₹{current_account['balance']:.2f}")
                elif amount > 25000:
                    print("   ❌ Maximum withdrawal limit is ₹25,000 per transaction!")
                else:
                    current_account['balance'] -= amount
                    print(f"   ✅ ₹{amount:.2f} withdrawn successfully!")
                    print(f"   💰 Remaining Balance: ₹{current_account['balance']:.2f}")
            except ValueError:
                print("   ❌ Invalid amount!")

        elif choice == '4':
            # Mini Statement
            print(f"\n   📋 MINI STATEMENT")
            print(f"   {'─' * 30}")
            print(f"   Account Holder: {current_account['name']}")
            print(f"   Balance       : ₹{current_account['balance']:.2f}")
            print(f"   {'─' * 30}")

        elif choice == '5':
            # Change PIN
            old_pin = input("\n   Enter current PIN: ")
            if old_pin == pin:
                new_pin = input("   Enter new 4-digit PIN: ")
                confirm_pin = input("   Confirm new PIN: ")
                if new_pin == confirm_pin and len(new_pin) == 4 and new_pin.isdigit():
                    # Move account to new PIN
                    accounts[new_pin] = accounts.pop(pin)
                    pin = new_pin
                    print("   ✅ PIN changed successfully!")
                else:
                    print("   ❌ PINs don't match or invalid format!")
            else:
                print("   ❌ Incorrect current PIN!")

        elif choice == '6':
            print(f"\n   {'=' * 40}")
            print(f"   Thank you, {current_account['name']}!")
            print(f"   Please collect your card. 💳")
            print(f"   {'=' * 40}")
            break

        else:
            print("   ❌ Invalid choice!")


# Main program
if __name__ == "__main__":
    atm_simulation()


# Expected Output:
# ==================================================
#    🏧 ATM SIMULATION SYSTEM
# ==================================================
#
#    📌 Demo PIN: 1234
#
#    Enter your 4-digit PIN (Attempt 1/3): 1234
#
#    ✅ Welcome, Rahul Sharma!
#
# ----------------------------------------
#    🏧 ATM MENU
# ----------------------------------------
#    1. Check Balance
#    2. Deposit Money
#    3. Withdraw Money
#    4. Mini Statement
#    5. Change PIN
#    6. Exit
# ----------------------------------------
#    Enter your choice (1-6): 1
#
#    💰 Current Balance: ₹50000.00
