# Q3. Write a menu-driven banking application using a while loop that allows users
# to deposit, withdraw, check balance, and exit with proper validation.

def banking_application():
    """Menu-driven banking application with deposit, withdraw, balance, and exit."""
    balance = 0.0  # Initial balance
    transaction_history = []  # Store transaction records

    print("=" * 50)
    print("   WELCOME TO PYTHON BANK")
    print("=" * 50)

    while True:
        # Display menu
        print("\n--- MAIN MENU ---")
        print("1. Deposit Money")
        print("2. Withdraw Money")
        print("3. Check Balance")
        print("4. Transaction History")
        print("5. Exit")
        print("-" * 20)

        # Accept user choice
        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            # Deposit Money
            try:
                amount = float(input("Enter amount to deposit: ₹"))
                if amount <= 0:
                    print("❌ Invalid amount! Please enter a positive value.")
                else:
                    balance += amount
                    transaction_history.append(f"Deposited: ₹{amount:.2f}")
                    print(f"✅ ₹{amount:.2f} deposited successfully!")
                    print(f"   Current Balance: ₹{balance:.2f}")
            except ValueError:
                print("❌ Invalid input! Please enter a numeric value.")

        elif choice == '2':
            # Withdraw Money
            try:
                amount = float(input("Enter amount to withdraw: ₹"))
                if amount <= 0:
                    print("❌ Invalid amount! Please enter a positive value.")
                elif amount > balance:
                    print(f"❌ Insufficient balance! Available: ₹{balance:.2f}")
                else:
                    balance -= amount
                    transaction_history.append(f"Withdrawn: ₹{amount:.2f}")
                    print(f"✅ ₹{amount:.2f} withdrawn successfully!")
                    print(f"   Current Balance: ₹{balance:.2f}")
            except ValueError:
                print("❌ Invalid input! Please enter a numeric value.")

        elif choice == '3':
            # Check Balance
            print(f"\n💰 Current Balance: ₹{balance:.2f}")

        elif choice == '4':
            # Transaction History
            if not transaction_history:
                print("\n📋 No transactions yet.")
            else:
                print("\n📋 Transaction History:")
                print("-" * 30)
                for i, txn in enumerate(transaction_history, 1):
                    print(f"  {i}. {txn}")
                print("-" * 30)

        elif choice == '5':
            # Exit
            print("\n" + "=" * 50)
            print("  Thank you for using Python Bank! Goodbye! 👋")
            print("=" * 50)
            break

        else:
            print("❌ Invalid choice! Please select from 1-5.")


# Main program
if __name__ == "__main__":
    banking_application()


# Expected Output:
# ==================================================
#    WELCOME TO PYTHON BANK
# ==================================================
#
# --- MAIN MENU ---
# 1. Deposit Money
# 2. Withdraw Money
# 3. Check Balance
# 4. Transaction History
# 5. Exit
# --------------------
# Enter your choice (1-5): 1
# Enter amount to deposit: ₹5000
# ✅ ₹5000.00 deposited successfully!
#    Current Balance: ₹5000.00
#
# Enter your choice (1-5): 2
# Enter amount to withdraw: ₹2000
# ✅ ₹2000.00 withdrawn successfully!
#    Current Balance: ₹3000.00
#
# Enter your choice (1-5): 3
# 💰 Current Balance: ₹3000.00
#
# Enter your choice (1-5): 5
# ==================================================
#   Thank you for using Python Bank! Goodbye! 👋
# ==================================================
