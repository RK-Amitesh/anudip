# Q20. Create a file processing program that handles file not found errors
# and counts total words, lines, and characters in a text file.

def create_sample_file(filename):
    """Create a sample text file for demonstration."""
    content = """Python is a powerful programming language.
It is widely used in web development, data science, and artificial intelligence.
Python has a simple and easy-to-learn syntax.
It supports multiple programming paradigms including procedural, object-oriented, and functional programming.
Python's extensive standard library makes it suitable for rapid application development.
The Python community is large and supportive, with millions of developers worldwide."""

    try:
        with open(filename, 'w') as f:
            f.write(content)
        print(f"✅ Sample file '{filename}' created successfully!")
    except IOError as e:
        print(f"❌ Error creating file: {e}")


def process_file(filename):
    """Process a text file and count words, lines, and characters."""
    try:
        with open(filename, 'r') as f:
            content = f.read()

        # Count lines
        lines = content.split('\n')
        line_count = len(lines)

        # Count words
        words = content.split()
        word_count = len(words)

        # Count characters (with and without spaces)
        char_count_with_spaces = len(content)
        char_count_without_spaces = len(content.replace(' ', '').replace('\n', ''))

        # Display results
        print("\n" + "=" * 50)
        print("   FILE ANALYSIS REPORT")
        print("=" * 50)
        print(f"   File Name              : {filename}")
        print(f"   Total Lines            : {line_count}")
        print(f"   Total Words            : {word_count}")
        print(f"   Total Characters       : {char_count_with_spaces}")
        print(f"   Characters (no spaces) : {char_count_without_spaces}")
        print("=" * 50)

        # Display file content
        print("\n📄 File Content:")
        print("-" * 50)
        for i, line in enumerate(lines, 1):
            print(f"  {i:>3} | {line}")
        print("-" * 50)

        # Display word frequency (top 5)
        word_freq = {}
        for word in words:
            word_lower = word.lower().strip('.,!?;:')
            word_freq[word_lower] = word_freq.get(word_lower, 0) + 1

        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:5]
        print("\n🔝 Top 5 Most Frequent Words:")
        for word, count in sorted_words:
            print(f"   '{word}' → {count} times")

    except FileNotFoundError:
        print(f"\n❌ FileNotFoundError: The file '{filename}' was not found!")
        print("   Please check the filename and try again.")
    except PermissionError:
        print(f"\n❌ PermissionError: No permission to read '{filename}'!")
    except IOError as e:
        print(f"\n❌ IOError: {e}")
    except Exception as e:
        print(f"\n❌ Unexpected Error: {e}")


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   FILE PROCESSING PROGRAM")
    print("=" * 50)

    print("\n1. Create sample file and process")
    print("2. Process an existing file")
    choice = input("\nEnter your choice (1/2): ")

    if choice == '1':
        filename = "sample_text.txt"
        create_sample_file(filename)
        process_file(filename)
    elif choice == '2':
        filename = input("Enter the filename: ").strip()
        process_file(filename)
    else:
        print("❌ Invalid choice!")


# Expected Output:
# ==================================================
#    FILE PROCESSING PROGRAM
# ==================================================
#
# 1. Create sample file and process
# 2. Process an existing file
#
# Enter your choice (1/2): 1
# ✅ Sample file 'sample_text.txt' created successfully!
#
# ==================================================
#    FILE ANALYSIS REPORT
# ==================================================
#    File Name              : sample_text.txt
#    Total Lines            : 6
#    Total Words            : 57
#    Total Characters       : 410
#    Characters (no spaces) : 354
# ==================================================
#
# 📄 File Content:
# --------------------------------------------------
#     1 | Python is a powerful programming language.
#     2 | It is widely used in web development...
#   ...
#
# 🔝 Top 5 Most Frequent Words:
#    'python' → 3 times
#    'is' → 3 times
#    'programming' → 2 times
#    ...
