# Q38. Generate random temperature data using NumPy and plot a histogram
# representing temperature distribution.

import numpy as np
import matplotlib
matplotlib.use('macosx')  # Use native macOS backend for GUI display
import matplotlib.pyplot as plt
from matplotlib.patches import Patch


def generate_and_plot_temperature():
    """Generate random temperature data and plot histogram."""

    # Generate random temperature data for 365 days
    np.random.seed(42)

    # Simulate realistic temperature data (mean=28 degrees C, std=8 degrees C for Indian climate)
    temperatures = np.random.normal(loc=28, scale=8, size=365)

    # Clip to realistic range
    temperatures = np.clip(temperatures, 5, 48)

    # Display statistics
    print("\n" + "=" * 55)
    print("   TEMPERATURE DATA STATISTICS")
    print("=" * 55)
    print(f"   Number of Days     : {len(temperatures)}")
    print(f"   Mean Temperature   : {np.mean(temperatures):.2f} C")
    print(f"   Median Temperature : {np.median(temperatures):.2f} C")
    print(f"   Max Temperature    : {np.max(temperatures):.2f} C")
    print(f"   Min Temperature    : {np.min(temperatures):.2f} C")
    print(f"   Std Deviation      : {np.std(temperatures):.2f} C")

    # Count days in temperature ranges
    print("\n   Temperature Distribution:")
    ranges = [(5, 15), (15, 25), (25, 35), (35, 48)]
    labels = ['Cold (5-15 C)', 'Pleasant (15-25 C)', 'Warm (25-35 C)', 'Hot (35-48 C)']
    for (low, high), label in zip(ranges, labels):
        count = np.sum((temperatures >= low) & (temperatures < high))
        print(f"   {label:<25}: {count} days")

    # Create histogram
    fig, ax = plt.subplots(figsize=(12, 7))

    # Plot histogram with custom styling
    n, bins, patches_hist = ax.hist(temperatures, bins=20, edgecolor='black',
                                    linewidth=0.8, alpha=0.85)

    # Color the bars based on temperature ranges
    for patch, left_edge in zip(patches_hist, bins[:-1]):
        if left_edge < 15:
            patch.set_facecolor('#3498DB')  # Blue for cold
        elif left_edge < 25:
            patch.set_facecolor('#2ECC71')  # Green for pleasant
        elif left_edge < 35:
            patch.set_facecolor('#F39C12')  # Orange for warm
        else:
            patch.set_facecolor('#E74C3C')  # Red for hot

    # Add mean line
    ax.axvline(np.mean(temperatures), color='red', linestyle='--',
               linewidth=2, label=f'Mean: {np.mean(temperatures):.1f} C')

    # Add median line
    ax.axvline(np.median(temperatures), color='blue', linestyle=':',
               linewidth=2, label=f'Median: {np.median(temperatures):.1f} C')

    # Labels and title
    ax.set_title('Daily Temperature Distribution (365 Days)', fontsize=16, fontweight='bold')
    ax.set_xlabel('Temperature (C)', fontsize=13, fontweight='bold')
    ax.set_ylabel('Number of Days', fontsize=13, fontweight='bold')

    # Legend
    legend_elements = [
        Patch(facecolor='#3498DB', label='Cold (<15 C)'),
        Patch(facecolor='#2ECC71', label='Pleasant (15-25 C)'),
        Patch(facecolor='#F39C12', label='Warm (25-35 C)'),
        Patch(facecolor='#E74C3C', label='Hot (>35 C)'),
    ]
    ax.legend(handles=legend_elements, fontsize=10, loc='upper right')

    # Grid
    ax.grid(axis='y', linestyle='--', alpha=0.5)
    ax.set_facecolor('#f8f9fa')

    plt.tight_layout()

    # Save chart
    plt.savefig('temperature_histogram.png', dpi=150, bbox_inches='tight')
    print(f"\n   Histogram saved as 'temperature_histogram.png'")

    plt.show()


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   TEMPERATURE DATA HISTOGRAM")
    print("=" * 55)

    generate_and_plot_temperature()


# Expected Output:
# =======================================================
#    TEMPERATURE DATA HISTOGRAM
# =======================================================
#
# =======================================================
#    TEMPERATURE DATA STATISTICS
# =======================================================
#    Number of Days     : 365
#    Mean Temperature   : 28.15 C
#    Median Temperature : 28.32 C
#    Max Temperature    : 47.50 C
#    Min Temperature    : 8.20 C
#    Std Deviation      : 7.85 C
#
#    Temperature Distribution:
#    Cold (5-15 C)            : 22 days
#    Pleasant (15-25 C)       : 98 days
#    Warm (25-35 C)           : 172 days
#    Hot (35-48 C)            : 73 days
#
#    Histogram saved as 'temperature_histogram.png'
# (Histogram window opens with colored bars showing temperature distribution)
