# Q21. Generate a NumPy array of student marks and convert it into a Pandas DataFrame.
# Display highest marks, average marks, and students failing (below 40).

import numpy as np
import pandas as pd


def generate_student_data():
    """Generate student marks data using NumPy and convert to Pandas DataFrame."""

    # Student names
    students = ['Rahul', 'Priya', 'Amit', 'Sneha', 'Rohan',
                'Kavita', 'Deepak', 'Anita', 'Suresh', 'Meera']

    # Subjects
    subjects = ['Maths', 'Science', 'English', 'Hindi', 'Computer']

    # Generate random marks using NumPy (0-100)
    np.random.seed(42)  # For reproducibility
    marks_array = np.random.randint(20, 100, size=(len(students), len(subjects)))

    # Create Pandas DataFrame
    df = pd.DataFrame(marks_array, columns=subjects, index=students)
    df.index.name = 'Student'

    return df


def analyze_marks(df):
    """Analyze student marks DataFrame."""

    # Display all student marks
    print("\n" + "=" * 65)
    print("   ALL STUDENT MARKS")
    print("=" * 65)
    print(df)

    # Calculate total and percentage for each student
    df['Total'] = df.sum(axis=1)
    df['Percentage'] = (df['Total'] / (5 * 100)) * 100

    print("\n" + "=" * 65)
    print("   STUDENT MARKS WITH TOTAL & PERCENTAGE")
    print("=" * 65)
    print(df)

    # Highest marks in each subject
    print("\n" + "=" * 65)
    print("   HIGHEST MARKS IN EACH SUBJECT")
    print("=" * 65)
    subjects = ['Maths', 'Science', 'English', 'Hindi', 'Computer']
    for subject in subjects:
        max_marks = df[subject].max()
        topper = df[subject].idxmax()
        print(f"   {subject:<12} : {topper} ({max_marks} marks)")

    # Average marks in each subject
    print("\n" + "=" * 65)
    print("   AVERAGE MARKS IN EACH SUBJECT")
    print("=" * 65)
    for subject in subjects:
        avg = df[subject].mean()
        print(f"   {subject:<12} : {avg:.2f}")

    # Overall topper
    overall_topper = df['Total'].idxmax()
    topper_total = df.loc[overall_topper, 'Total']
    topper_pct = df.loc[overall_topper, 'Percentage']
    print(f"\n🏆 Overall Topper: {overall_topper} (Total: {topper_total}, Percentage: {topper_pct:.2f}%)")

    # Students failing (marks below 40 in any subject)
    print("\n" + "=" * 65)
    print("   STUDENTS FAILING (Marks < 40 in any subject)")
    print("=" * 65)

    failing_students = []
    for student in df.index:
        failed_subjects = []
        for subject in subjects:
            if df.loc[student, subject] < 40:
                failed_subjects.append(f"{subject}({df.loc[student, subject]})")
        if failed_subjects:
            failing_students.append((student, failed_subjects))

    if failing_students:
        for student, subjects_failed in failing_students:
            print(f"   ❌ {student}: Failed in {', '.join(subjects_failed)}")
    else:
        print("   ✅ No students failing!")

    # Overall class average
    overall_avg = df['Percentage'].mean()
    print(f"\n📊 Overall Class Average: {overall_avg:.2f}%")


# Main program
if __name__ == "__main__":
    print("=" * 65)
    print("   STUDENT MARKS ANALYSIS (NumPy + Pandas)")
    print("=" * 65)

    df = generate_student_data()
    analyze_marks(df)


# Expected Output:
# =================================================================
#    STUDENT MARKS ANALYSIS (NumPy + Pandas)
# =================================================================
#
# =================================================================
#    ALL STUDENT MARKS
# =================================================================
#          Maths  Science  English  Hindi  Computer
# Student
# Rahul       71       20      52     93        52
# Priya       45       80      43     88        65
# ...
#
# =================================================================
#    HIGHEST MARKS IN EACH SUBJECT
# =================================================================
#    Maths        : Sneha (95 marks)
#    Science      : Priya (80 marks)
#    ...
#
# 🏆 Overall Topper: Sneha (Total: 380, Percentage: 76.00%)
#
# =================================================================
#    STUDENTS FAILING (Marks < 40 in any subject)
# =================================================================
#    ❌ Rahul: Failed in Science(20)
#    ...
#
# 📊 Overall Class Average: 58.50%
