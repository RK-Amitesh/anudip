# Q4. Design a Python function that accepts a list of integers and returns the
# second largest and second smallest elements without using built-in sorting.

def find_second_largest(numbers):
    """Find the second largest element without using built-in sorting."""
    if len(numbers) < 2:
        return None

    # Find the largest
    largest = float('-inf')
    for num in numbers:
        if num > largest:
            largest = num

    # Find the second largest (largest number that is less than the largest)
    second_largest = float('-inf')
    for num in numbers:
        if num > second_largest and num < largest:
            second_largest = num

    return second_largest if second_largest != float('-inf') else None


def find_second_smallest(numbers):
    """Find the second smallest element without using built-in sorting."""
    if len(numbers) < 2:
        return None

    # Find the smallest
    smallest = float('inf')
    for num in numbers:
        if num < smallest:
            smallest = num

    # Find the second smallest (smallest number that is greater than the smallest)
    second_smallest = float('inf')
    for num in numbers:
        if num < second_smallest and num > smallest:
            second_smallest = num

    return second_smallest if second_smallest != float('inf') else None


def find_second_largest_and_smallest(numbers):
    """Find both second largest and second smallest elements."""
    second_largest = find_second_largest(numbers)
    second_smallest = find_second_smallest(numbers)
    return second_largest, second_smallest


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   SECOND LARGEST & SECOND SMALLEST FINDER")
    print("=" * 50)

    # Accept list of integers from user
    user_input = input("\nEnter integers separated by spaces: ")
    numbers = list(map(int, user_input.split()))

    print(f"\nOriginal List: {numbers}")
    print("-" * 40)

    # Find second largest and second smallest
    second_largest, second_smallest = find_second_largest_and_smallest(numbers)

    if second_largest is not None:
        print(f"Second Largest  : {second_largest}")
    else:
        print("Second Largest  : Not enough unique elements")

    if second_smallest is not None:
        print(f"Second Smallest : {second_smallest}")
    else:
        print("Second Smallest : Not enough unique elements")


# Expected Output:
# ==================================================
#    SECOND LARGEST & SECOND SMALLEST FINDER
# ==================================================
#
# Enter integers separated by spaces: 12 5 8 3 20 15 1 9
#
# Original List: [12, 5, 8, 3, 20, 15, 1, 9]
# ----------------------------------------
# Second Largest  : 15
# Second Smallest : 3
