# Q31. Plot a pie chart showing market share of different smartphone brands
# and highlight the brand with maximum market share.

import matplotlib
matplotlib.use('macosx')  # Use native macOS backend for GUI display
import matplotlib.pyplot as plt


def create_pie_chart():
    """Create a pie chart for smartphone market share."""

    # Smartphone brands and their market share
    brands = ['Samsung', 'Apple', 'Xiaomi', 'Oppo', 'Vivo', 'OnePlus', 'Others']
    market_share = [22, 27, 15, 10, 8, 6, 12]

    # Find the brand with maximum market share
    max_index = market_share.index(max(market_share))

    # Explode the slice with maximum market share
    explode = [0] * len(brands)
    explode[max_index] = 0.1  # Highlight the max brand

    # Custom colors
    colors = ['#3498DB', '#E74C3C', '#FF9800', '#2ECC71', '#9B59B6', '#E91E63', '#95A5A6']

    # Create figure
    fig, ax = plt.subplots(figsize=(10, 8))

    # Create pie chart
    wedges, texts, autotexts = ax.pie(
        market_share,
        explode=explode,
        labels=brands,
        autopct='%1.1f%%',
        colors=colors,
        shadow=True,
        startangle=140,
        pctdistance=0.85,
        textprops={'fontsize': 12}
    )

    # Style the percentage text
    for autotext in autotexts:
        autotext.set_fontweight('bold')
        autotext.set_fontsize(11)

    # Add title
    ax.set_title('Smartphone Market Share 2025',
                 fontsize=16, fontweight='bold', pad=20)

    # Add legend
    ax.legend(wedges, [f'{brand} ({share}%)' for brand, share in zip(brands, market_share)],
              title="Brands",
              loc="center left",
              bbox_to_anchor=(1, 0, 0.5, 1),
              fontsize=10)

    # Highlight annotation for max brand
    ax.annotate(f'Market Leader: {brands[max_index]} ({market_share[max_index]}%)',
                xy=(0.5, -0.1), xycoords='axes fraction',
                ha='center', fontsize=13, fontweight='bold',
                color=colors[max_index])

    plt.tight_layout()

    # Save chart
    plt.savefig('smartphone_market_share.png', dpi=150, bbox_inches='tight')
    print("Pie chart saved as 'smartphone_market_share.png'")

    plt.show()


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   SMARTPHONE MARKET SHARE PIE CHART")
    print("=" * 55)

    create_pie_chart()


# Expected Output:
# =======================================================
#    SMARTPHONE MARKET SHARE PIE CHART
# =======================================================
# Pie chart saved as 'smartphone_market_share.png'
# (A pie chart window opens showing market share with Apple highlighted
#  as the market leader at 27%, with custom colors and legend)
