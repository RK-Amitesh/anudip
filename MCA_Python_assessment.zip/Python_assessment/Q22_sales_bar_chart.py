# Q22. Read sales data from a CSV file using Pandas and plot a bar chart
# representing product-wise sales using Matplotlib.

import pandas as pd
import matplotlib.pyplot as plt


def create_sales_csv(filename):
    """Create a sample sales CSV file."""
    data = {
        'Product': ['Laptop', 'Mobile', 'Tablet', 'Headphones', 'Smartwatch',
                     'Camera', 'Speaker', 'Keyboard', 'Mouse', 'Monitor'],
        'Category': ['Electronics', 'Electronics', 'Electronics', 'Accessories', 'Wearable',
                      'Electronics', 'Accessories', 'Accessories', 'Accessories', 'Electronics'],
        'Units_Sold': [150, 320, 95, 450, 200, 80, 275, 180, 350, 120],
        'Revenue': [1125000, 1280000, 380000, 450000, 600000,
                    400000, 275000, 90000, 175000, 480000]
    }

    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"Sales CSV file '{filename}' created successfully!")
    return filename


def plot_sales_bar_chart(filename):
    """Read CSV and plot a bar chart for product-wise sales."""

    # Read sales data from CSV file using Pandas
    df = pd.read_csv(filename)
    print("\nSales Data from CSV:")
    print(df.to_string(index=False))

    # Create figure with two subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))

    # Color palette
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
              '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9']

    # Bar Chart 1: Units Sold per Product
    bars1 = ax1.bar(df['Product'], df['Units_Sold'], color=colors, edgecolor='black', linewidth=0.5)
    ax1.set_title('Product-wise Units Sold', fontsize=14, fontweight='bold')
    ax1.set_xlabel('Products', fontsize=12)
    ax1.set_ylabel('Units Sold', fontsize=12)
    ax1.tick_params(axis='x', rotation=45)
    ax1.grid(axis='y', linestyle='--', alpha=0.7)

    # Add value labels on bars
    for bar in bars1:
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width() / 2., height + 5,
                 f'{int(height)}', ha='center', va='bottom', fontweight='bold', fontsize=9)

    # Bar Chart 2: Revenue per Product
    bars2 = ax2.bar(df['Product'], df['Revenue'] / 1000, color=colors, edgecolor='black', linewidth=0.5)
    ax2.set_title('Product-wise Revenue (in Thousands)', fontsize=14, fontweight='bold')
    ax2.set_xlabel('Products', fontsize=12)
    ax2.set_ylabel('Revenue (in Thousands)', fontsize=12)
    ax2.tick_params(axis='x', rotation=45)
    ax2.grid(axis='y', linestyle='--', alpha=0.7)

    # Add value labels on bars
    for bar in bars2:
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width() / 2., height + 10,
                 f'{int(height)}K', ha='center', va='bottom', fontweight='bold', fontsize=9)

    # Add main title
    plt.suptitle('Sales Data Analysis Dashboard', fontsize=16, fontweight='bold', y=1.02)
    plt.tight_layout()

    # Save the chart
    plt.savefig('product_sales_chart.png', dpi=150, bbox_inches='tight')
    print("\nBar chart saved as 'product_sales_chart.png'")

    # Display the chart
    plt.show()


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   PRODUCT-WISE SALES BAR CHART")
    print("=" * 55)

    filename = "sales_data.csv"

    # Step 1: Create sample CSV file
    create_sales_csv(filename)

    # Step 2: Read CSV and plot bar chart
    plot_sales_bar_chart(filename)


# Expected Output:
# =======================================================
#    PRODUCT-WISE SALES BAR CHART
# =======================================================
#
# Sales CSV file 'sales_data.csv' created successfully!
#
# Sales Data from CSV:
#      Product     Category  Units_Sold   Revenue
#       Laptop  Electronics         150   1125000
#       Mobile  Electronics         320   1280000
#       Tablet  Electronics          95    380000
#   Headphones  Accessories         450    450000
#   Smartwatch     Wearable         200    600000
#       Camera  Electronics          80    400000
#      Speaker  Accessories         275    275000
#     Keyboard  Accessories         180     90000
#        Mouse  Accessories         350    175000
#      Monitor  Electronics         120    480000
#
# Bar chart saved as 'product_sales_chart.png'
# (Bar chart window opens showing product-wise units sold and revenue)
