# Q25. Store word frequencies from a text file into a dictionary and display
# the top five most frequently used words.

import string


def read_file(filename):
    """Read content from a text file."""
    try:
        with open(filename, 'r') as f:
            return f.read()
    except FileNotFoundError:
        print(f"❌ File '{filename}' not found!")
        return None


def create_sample_file(filename):
    """Create a sample text file for demonstration."""
    content = """Python is a versatile programming language that is widely used in the world of technology.
Python is known for its simple syntax and readability. Many developers choose Python for web development
and data science projects. Python supports multiple programming paradigms. The Python community is
one of the largest programming communities in the world. Learning Python is considered easy for beginners.
Python has extensive libraries that make development faster and more efficient.
Data science and machine learning are popular fields where Python is extensively used.
Python frameworks like Django and Flask are used for web development."""

    with open(filename, 'w') as f:
        f.write(content)
    print(f"✅ Sample file '{filename}' created!")


def count_word_frequencies(content):
    """Count word frequencies and store in a dictionary."""
    # Clean and convert to lowercase
    content = content.lower()

    # Remove punctuation
    content = content.translate(str.maketrans('', '', string.punctuation))

    # Split into words
    words = content.split()

    # Count frequencies using dictionary
    word_freq = {}
    for word in words:
        word_freq[word] = word_freq.get(word, 0) + 1

    return word_freq


def display_top_n_words(word_freq, n=5):
    """Display the top N most frequently used words."""
    # Sort by frequency (descending)
    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)

    print(f"\n🔝 Top {n} Most Frequently Used Words:")
    print("-" * 45)
    print(f"{'Rank':<6} {'Word':<20} {'Frequency':>10}")
    print("-" * 45)

    for i, (word, count) in enumerate(sorted_words[:n], 1):
        bar = "█" * count
        print(f"{i:<6} {word:<20} {count:>10}  {bar}")

    print("-" * 45)

    # Total statistics
    total_words = sum(word_freq.values())
    unique_words = len(word_freq)
    print(f"\n📊 Total Words: {total_words}")
    print(f"📊 Unique Words: {unique_words}")


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   TOP 5 WORD FREQUENCY ANALYZER")
    print("=" * 50)

    print("\n1. Use sample text file")
    print("2. Enter your own filename")
    choice = input("\nEnter your choice (1/2): ")

    if choice == '1':
        filename = "word_freq_sample.txt"
        create_sample_file(filename)
    elif choice == '2':
        filename = input("Enter filename: ").strip()
    else:
        print("❌ Invalid choice!")
        exit()

    # Read file content
    content = read_file(filename)

    if content:
        # Count word frequencies
        word_freq = count_word_frequencies(content)

        # Display all words and frequencies
        print("\n" + "=" * 50)
        print("   COMPLETE WORD FREQUENCY DICTIONARY")
        print("=" * 50)
        sorted_all = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        for word, count in sorted_all:
            print(f"   '{word}': {count}")

        # Display top 5 words
        display_top_n_words(word_freq, n=5)


# Expected Output:
# ==================================================
#    TOP 5 WORD FREQUENCY ANALYZER
# ==================================================
#
# 1. Use sample text file
# 2. Enter your own filename
#
# Enter your choice (1/2): 1
# ✅ Sample file 'word_freq_sample.txt' created!
#
# ==================================================
#    COMPLETE WORD FREQUENCY DICTIONARY
# ==================================================
#    'python': 8
#    'is': 6
#    'for': 4
#    ...
#
# 🔝 Top 5 Most Frequently Used Words:
# ---------------------------------------------
# Rank   Word                 Frequency
# ---------------------------------------------
# 1      python                        8  ████████
# 2      is                            6  ██████
# 3      for                           4  ████
# 4      and                           4  ████
# 5      the                           3  ███
# ---------------------------------------------
#
# 📊 Total Words: 85
# 📊 Unique Words: 52
