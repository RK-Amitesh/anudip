# Q17. Create a program that checks whether numbers entered by the user are
# Armstrong numbers using loops and conditional statements.

def is_armstrong(number):
    """Check if a number is an Armstrong number.
    An Armstrong number is a number where the sum of its digits 
    raised to the power of the number of digits equals the number itself.
    Example: 153 = 1^3 + 5^3 + 3^3 = 1 + 125 + 27 = 153
    """
    # Convert to string to get individual digits
    num_str = str(abs(number))
    num_digits = len(num_str)

    # Calculate sum of digits raised to the power of number of digits
    total = 0
    for digit in num_str:
        total += int(digit) ** num_digits

    return total == number


def find_armstrong_in_range(start, end):
    """Find all Armstrong numbers in a given range."""
    armstrong_numbers = []
    for num in range(start, end + 1):
        if is_armstrong(num):
            armstrong_numbers.append(num)
    return armstrong_numbers


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   ARMSTRONG NUMBER CHECKER")
    print("=" * 50)

    print("\n1. Check a single number")
    print("2. Check multiple numbers")
    print("3. Find Armstrong numbers in a range")
    choice = input("\nEnter your choice (1/2/3): ")

    if choice == '1':
        # Check single number
        num = int(input("\nEnter a number: "))
        if is_armstrong(num):
            # Show the calculation
            num_str = str(num)
            n = len(num_str)
            calculation = " + ".join([f"{d}^{n}" for d in num_str])
            result = " + ".join([str(int(d) ** n) for d in num_str])
            print(f"\n✅ {num} IS an Armstrong number!")
            print(f"   {calculation} = {result} = {num}")
        else:
            num_str = str(num)
            n = len(num_str)
            total = sum(int(d) ** n for d in num_str)
            print(f"\n❌ {num} is NOT an Armstrong number.")
            print(f"   Sum of digits^{n} = {total} ≠ {num}")

    elif choice == '2':
        # Check multiple numbers
        user_input = input("\nEnter numbers separated by spaces: ")
        numbers = list(map(int, user_input.split()))

        print(f"\n{'Number':>10} {'Armstrong?':>15} {'Explanation'}")
        print("-" * 55)
        for num in numbers:
            num_str = str(num)
            n = len(num_str)
            total = sum(int(d) ** n for d in num_str)
            status = "✅ Yes" if is_armstrong(num) else "❌ No"
            calculation = " + ".join([f"{d}^{n}" for d in num_str])
            print(f"{num:>10} {status:>15}  ({calculation} = {total})")

    elif choice == '3':
        # Find Armstrong numbers in a range
        start = int(input("\nEnter start of range: "))
        end = int(input("Enter end of range: "))

        armstrong_list = find_armstrong_in_range(start, end)

        print(f"\n📊 Armstrong Numbers between {start} and {end}:")
        if armstrong_list:
            print(f"   {armstrong_list}")
            print(f"   Total Count: {len(armstrong_list)}")
        else:
            print("   None found in this range.")

    else:
        print("❌ Invalid choice!")


# Expected Output:
# ==================================================
#    ARMSTRONG NUMBER CHECKER
# ==================================================
#
# 1. Check a single number
# 2. Check multiple numbers
# 3. Find Armstrong numbers in a range
#
# Enter your choice (1/2/3): 3
#
# Enter start of range: 1
# Enter end of range: 1000
#
# 📊 Armstrong Numbers between 1 and 1000:
#    [1, 2, 3, 4, 5, 6, 7, 8, 9, 153, 370, 371, 407]
#    Total Count: 13
