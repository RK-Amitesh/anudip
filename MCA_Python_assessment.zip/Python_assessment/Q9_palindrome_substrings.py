# Q9. Write a program to find all palindrome substrings in a given string
# after removing spaces, punctuation marks, and converting all characters to lowercase.

import string


def clean_string(text):
    """Remove spaces, punctuation and convert to lowercase."""
    cleaned = ""
    for char in text:
        if char not in string.punctuation and not char.isspace():
            cleaned += char.lower()
    return cleaned


def is_palindrome(s):
    """Check if a string is a palindrome."""
    return s == s[::-1]


def find_palindrome_substrings(text):
    """Find all unique palindrome substrings of length >= 2."""
    palindromes = set()
    n = len(text)

    # Check all possible substrings of length >= 2
    for i in range(n):
        for j in range(i + 2, n + 1):
            substring = text[i:j]
            if is_palindrome(substring):
                palindromes.add(substring)

    return sorted(palindromes, key=len, reverse=True)


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   PALINDROME SUBSTRING FINDER")
    print("=" * 55)

    # Accept string from user
    original_text = input("\nEnter a string: ")

    # Clean the string
    cleaned_text = clean_string(original_text)

    print(f"\nOriginal String : '{original_text}'")
    print(f"Cleaned String  : '{cleaned_text}'")
    print("-" * 55)

    # Find palindrome substrings
    palindromes = find_palindrome_substrings(cleaned_text)

    if palindromes:
        print(f"\n✅ Found {len(palindromes)} palindrome substring(s):\n")
        for i, p in enumerate(palindromes, 1):
            print(f"  {i}. '{p}' (length: {len(p)})")
    else:
        print("\n❌ No palindrome substrings found.")

    # Also check if the entire cleaned string is a palindrome
    print("\n" + "-" * 55)
    if is_palindrome(cleaned_text) and len(cleaned_text) >= 2:
        print(f"✅ The entire cleaned string '{cleaned_text}' IS a palindrome!")
    else:
        print(f"❌ The entire cleaned string '{cleaned_text}' is NOT a palindrome.")


# Expected Output:
# =======================================================
#    PALINDROME SUBSTRING FINDER
# =======================================================
#
# Enter a string: A man, a plan, a canal: Panama!
#
# Original String : 'A man, a plan, a canal: Panama!'
# Cleaned String  : 'amanaplanacanalpanama'
# -------------------------------------------------------
#
# ✅ Found multiple palindrome substring(s):
#
#   1. 'amanaplanacanalpanama' (length: 20)
#   2. 'anaplanacanalpana' (length: 17)
#   3. 'anacanacanalpana' (length: 16)
#   ...
#
# -------------------------------------------------------
# ✅ The entire cleaned string 'amanaplanacanalpanama' IS a palindrome!
