# Q14. Create a line chart using Matplotlib to display monthly sales data of a company.
# Add title, labels, legend, grid, and customize line styles and markers.

import matplotlib.pyplot as plt


def create_sales_line_chart():
    """Create a customized line chart for monthly sales data."""

    # Monthly sales data for two years
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
              'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

    # Sales data (in thousands)
    sales_2024 = [120, 135, 148, 160, 175, 190, 185, 200, 210, 225, 250, 280]
    sales_2025 = [140, 155, 170, 180, 195, 210, 220, 235, 245, 260, 285, 310]

    # Create figure with custom size
    plt.figure(figsize=(12, 6))

    # Plot sales data with custom line styles and markers
    plt.plot(months, sales_2024,
             color='#2196F3',
             marker='o',
             markersize=8,
             linewidth=2.5,
             linestyle='-',
             label='Sales 2024',
             markerfacecolor='white',
             markeredgewidth=2)

    plt.plot(months, sales_2025,
             color='#FF5722',
             marker='s',
             markersize=8,
             linewidth=2.5,
             linestyle='--',
             label='Sales 2025',
             markerfacecolor='white',
             markeredgewidth=2)

    # Add title and labels
    plt.title('Monthly Sales Data - Company XYZ', fontsize=16, fontweight='bold', pad=15)
    plt.xlabel('Months', fontsize=13, fontweight='bold')
    plt.ylabel('Sales (in Thousands)', fontsize=13, fontweight='bold')

    # Add legend
    plt.legend(fontsize=11, loc='upper left', framealpha=0.9)

    # Add grid
    plt.grid(True, linestyle='--', alpha=0.7, color='gray')

    # Customize tick labels
    plt.xticks(fontsize=10)
    plt.yticks(fontsize=10)

    # Set background color
    plt.gca().set_facecolor('#f8f9fa')

    # Add tight layout for better spacing
    plt.tight_layout()

    # Save the chart as image file
    plt.savefig('monthly_sales_chart.png', dpi=150, bbox_inches='tight')
    print("Chart saved as 'monthly_sales_chart.png'")

    # Display the chart
    plt.show()


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   MONTHLY SALES LINE CHART GENERATOR")
    print("=" * 50)

    create_sales_line_chart()


# Expected Output:
# ==================================================
#    MONTHLY SALES LINE CHART GENERATOR
# ==================================================
# Chart saved as 'monthly_sales_chart.png'
# (A line chart window will open displaying monthly sales data
#  with two lines for 2024 and 2025, custom markers, grid,
#  title, labels, and legend)
