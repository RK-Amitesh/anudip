# Q30. Write a NumPy program to create two matrices and perform addition, subtraction,
# multiplication, and element-wise operations.

import numpy as np


def matrix_operations():
    """Perform various matrix operations using NumPy."""
    print("=" * 55)
    print("   NUMPY MATRIX OPERATIONS")
    print("=" * 55)

    # Get matrix dimensions
    rows = int(input("\nEnter number of rows: "))
    cols = int(input("Enter number of columns: "))

    # Create two matrices with random integers
    np.random.seed(10)
    matrix_a = np.random.randint(1, 10, size=(rows, cols))
    matrix_b = np.random.randint(1, 10, size=(rows, cols))

    # Display original matrices
    print(f"\n📊 Matrix A ({rows}x{cols}):")
    print(matrix_a)
    print(f"\n📊 Matrix B ({rows}x{cols}):")
    print(matrix_b)

    # 1. Addition
    addition = matrix_a + matrix_b
    print(f"\n1️⃣  Matrix Addition (A + B):")
    print(addition)

    # 2. Subtraction
    subtraction = matrix_a - matrix_b
    print(f"\n2️⃣  Matrix Subtraction (A - B):")
    print(subtraction)

    # 3. Element-wise Multiplication
    elem_multiplication = matrix_a * matrix_b
    print(f"\n3️⃣  Element-wise Multiplication (A * B):")
    print(elem_multiplication)

    # 4. Matrix Multiplication (if square or compatible)
    if cols == rows:
        mat_multiplication = np.dot(matrix_a, matrix_b)
        print(f"\n4️⃣  Matrix Multiplication (A @ B):")
        print(mat_multiplication)
    else:
        # Multiply A with transpose of B
        mat_multiplication = np.dot(matrix_a, matrix_b.T)
        print(f"\n4️⃣  Matrix Multiplication (A @ B^T) [{rows}x{rows}]:")
        print(mat_multiplication)

    # 5. Element-wise Division
    elem_division = matrix_a / matrix_b
    print(f"\n5️⃣  Element-wise Division (A / B):")
    print(np.round(elem_division, 2))

    # 6. Element-wise Power
    elem_power = matrix_a ** 2
    print(f"\n6️⃣  Element-wise Square (A²):")
    print(elem_power)

    # 7. Element-wise Square Root
    elem_sqrt = np.sqrt(matrix_a.astype(float))
    print(f"\n7️⃣  Element-wise Square Root (√A):")
    print(np.round(elem_sqrt, 2))

    # Additional Statistics
    print("\n" + "=" * 55)
    print("   MATRIX STATISTICS")
    print("=" * 55)
    print(f"\n   Matrix A:")
    print(f"   Sum: {np.sum(matrix_a)}, Mean: {np.mean(matrix_a):.2f}, Max: {np.max(matrix_a)}, Min: {np.min(matrix_a)}")
    print(f"\n   Matrix B:")
    print(f"   Sum: {np.sum(matrix_b)}, Mean: {np.mean(matrix_b):.2f}, Max: {np.max(matrix_b)}, Min: {np.min(matrix_b)}")


# Main program
if __name__ == "__main__":
    matrix_operations()


# Expected Output:
# =======================================================
#    NUMPY MATRIX OPERATIONS
# =======================================================
#
# Enter number of rows: 3
# Enter number of columns: 3
#
# 📊 Matrix A (3x3):
# [[5 1 2]
#  [9 8 4]
#  [3 7 6]]
#
# 📊 Matrix B (3x3):
# [[2 8 1]
#  [5 3 9]
#  [4 6 7]]
#
# 1️⃣  Matrix Addition (A + B):
# [[ 7  9  3]
#  [14 11 13]
#  [ 7 13 13]]
#
# 2️⃣  Matrix Subtraction (A - B):
# [[ 3 -7  1]
#  [ 4  5 -5]
#  [-1  1 -1]]
#
# 3️⃣  Element-wise Multiplication (A * B):
# [[10  8  2]
#  [45 24 36]
#  [12 42 42]]
# ...
