# Q1. Write a Python program that accepts a paragraph from the user and calculates
# the number of uppercase letters, lowercase letters, digits, spaces, and special characters.
# Display the results in descending order based on their frequency.

def analyze_paragraph(paragraph):
    """Analyze a paragraph and count different character types."""
    uppercase_count = 0
    lowercase_count = 0
    digit_count = 0
    space_count = 0
    special_count = 0

    # Iterate through each character and classify it
    for char in paragraph:
        if char.isupper():
            uppercase_count += 1
        elif char.islower():
            lowercase_count += 1
        elif char.isdigit():
            digit_count += 1
        elif char.isspace():
            space_count += 1
        else:
            special_count += 1

    # Store results in a dictionary for sorting
    results = {
        "Lowercase Letters": lowercase_count,
        "Uppercase Letters": uppercase_count,
        "Digits": digit_count,
        "Spaces": space_count,
        "Special Characters": special_count
    }

    # Sort results in descending order based on frequency
    sorted_results = sorted(results.items(), key=lambda x: x[1], reverse=True)

    return sorted_results


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   PARAGRAPH CHARACTER ANALYSIS PROGRAM")
    print("=" * 50)

    # Accept paragraph from user
    paragraph = input("\nEnter a paragraph: ")

    # Analyze the paragraph
    sorted_results = analyze_paragraph(paragraph)

    # Display results in descending order of frequency
    print("\n" + "-" * 40)
    print("Character Analysis Results (Descending Order):")
    print("-" * 40)
    print(f"{'Category':<25} {'Count':>5}")
    print("-" * 40)

    for category, count in sorted_results:
        print(f"{category:<25} {count:>5}")

    print("-" * 40)
    print(f"{'Total Characters':<25} {len(paragraph):>5}")


# Expected Output:
# ==================================================
#    PARAGRAPH CHARACTER ANALYSIS PROGRAM
# ==================================================
#
# Enter a paragraph: Hello World! 123 Python is GREAT.
#
# ----------------------------------------
# Character Analysis Results (Descending Order):
# ----------------------------------------
# Category                  Count
# ----------------------------------------
# Lowercase Letters            16
# Spaces                        5
# Uppercase Letters              4
# Digits                         3
# Special Characters             2
# ----------------------------------------
# Total Characters              30
