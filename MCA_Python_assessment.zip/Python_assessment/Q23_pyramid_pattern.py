# Q23. Write a program to print a pyramid pattern of numbers and calculate
# the sum of all numbers printed in the pyramid.

def print_number_pyramid(rows):
    """Print a pyramid pattern of numbers and calculate sum."""
    total_sum = 0
    number = 1

    print(f"\n📐 Number Pyramid ({rows} rows):\n")

    for i in range(1, rows + 1):
        # Print leading spaces for pyramid shape
        spaces = "  " * (rows - i)
        print(spaces, end="")

        # Print numbers in the row
        row_numbers = []
        for j in range(1, i + 1):
            row_numbers.append(number)
            total_sum += number
            number += 1

        # Format and print the row
        row_str = "  ".join(f"{num:>3}" for num in row_numbers)
        print(row_str)

    return total_sum


def print_pattern_pyramid(rows):
    """Print different pyramid pattern styles."""

    # Pattern 1: Simple number pyramid (1, 2, 3...)
    print("\n🔺 Pattern 1: Sequential Number Pyramid")
    total = print_number_pyramid(rows)
    print(f"\n   Sum of all numbers: {total}")

    # Pattern 2: Row-repeating pyramid
    print(f"\n🔺 Pattern 2: Row-Repeating Pyramid ({rows} rows):\n")
    total_sum_2 = 0
    for i in range(1, rows + 1):
        spaces = "  " * (rows - i)
        row = f"{i} " * i
        print(f"{spaces}{row.strip()}")
        total_sum_2 += i * i  # i repeated i times

    print(f"\n   Sum of all numbers: {total_sum_2}")

    # Pattern 3: Floyd's Triangle
    print(f"\n🔺 Pattern 3: Floyd's Triangle ({rows} rows):\n")
    num = 1
    total_sum_3 = 0
    for i in range(1, rows + 1):
        for j in range(1, i + 1):
            print(f"{num:>4}", end="")
            total_sum_3 += num
            num += 1
        print()

    print(f"\n   Sum of all numbers: {total_sum_3}")


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   NUMBER PYRAMID PATTERN GENERATOR")
    print("=" * 50)

    # Accept number of rows from user
    rows = int(input("\nEnter the number of rows: "))

    if rows <= 0:
        print("❌ Please enter a positive integer!")
    else:
        print_pattern_pyramid(rows)


# Expected Output:
# ==================================================
#    NUMBER PYRAMID PATTERN GENERATOR
# ==================================================
#
# Enter the number of rows: 5
#
# 🔺 Pattern 1: Sequential Number Pyramid
#
# 📐 Number Pyramid (5 rows):
#
#             1
#           2    3
#         4    5    6
#       7    8    9   10
#     11   12   13   14   15
#
#    Sum of all numbers: 120
#
# 🔺 Pattern 2: Row-Repeating Pyramid (5 rows):
#
#         1
#       2 2
#     3 3 3
#   4 4 4 4
# 5 5 5 5 5
#
#    Sum of all numbers: 55
#
# 🔺 Pattern 3: Floyd's Triangle (5 rows):
#
#    1
#    2   3
#    4   5   6
#    7   8   9  10
#   11  12  13  14  15
#
#    Sum of all numbers: 120
