# Q13. Write a NumPy program to create a 1D matrix with random integers and
# calculate row-wise sum, column-wise sum, transpose, and reshape.

import numpy as np


def numpy_matrix_operations():
    """Perform various NumPy matrix operations."""
    print("=" * 55)
    print("   NUMPY MATRIX OPERATIONS PROGRAM")
    print("=" * 55)

    # Get dimensions from user
    rows = int(input("\nEnter number of rows: "))
    cols = int(input("Enter number of columns: "))

    # Create a matrix with random integers (1-50)
    matrix = np.random.randint(1, 51, size=(rows, cols))

    print(f"\n📊 Original Matrix ({rows}x{cols}):")
    print(matrix)

    # 1. Row-wise Sum
    row_sum = np.sum(matrix, axis=1)
    print(f"\n1️⃣  Row-wise Sum: {row_sum}")

    # 2. Column-wise Sum
    col_sum = np.sum(matrix, axis=0)
    print(f"\n2️⃣  Column-wise Sum: {col_sum}")

    # 3. Transpose
    transpose = matrix.T
    print(f"\n3️⃣  Transpose ({cols}x{rows}):")
    print(transpose)

    # 4. Reshape (to 1D array)
    total_elements = rows * cols
    reshaped_1d = matrix.reshape(1, total_elements)
    print(f"\n4️⃣  Reshaped to 1D (1x{total_elements}):")
    print(reshaped_1d)

    # 5. Reshape to different dimensions (if possible)
    if total_elements % 2 == 0:
        new_rows = 2
        new_cols = total_elements // 2
        reshaped_2d = matrix.reshape(new_rows, new_cols)
        print(f"\n5️⃣  Reshaped to ({new_rows}x{new_cols}):")
        print(reshaped_2d)

    # Additional Statistics
    print("\n" + "=" * 55)
    print("   ADDITIONAL STATISTICS")
    print("=" * 55)
    print(f"   Total Sum     : {np.sum(matrix)}")
    print(f"   Mean          : {np.mean(matrix):.2f}")
    print(f"   Max Element   : {np.max(matrix)}")
    print(f"   Min Element   : {np.min(matrix)}")
    print(f"   Std Deviation : {np.std(matrix):.2f}")


# Main program
if __name__ == "__main__":
    numpy_matrix_operations()


# Expected Output:
# =======================================================
#    NUMPY MATRIX OPERATIONS PROGRAM
# =======================================================
#
# Enter number of rows: 3
# Enter number of columns: 4
#
# 📊 Original Matrix (3x4):
# [[12 45  3 28]
#  [17 33  9 41]
#  [ 5 22 38 15]]
#
# 1️⃣  Row-wise Sum: [88 100 80]
#
# 2️⃣  Column-wise Sum: [34 100 50 84]
#
# 3️⃣  Transpose (4x3):
# [[12 17  5]
#  [45 33 22]
#  [ 3  9 38]
#  [28 41 15]]
#
# 4️⃣  Reshaped to 1D (1x12):
# [[12 45  3 28 17 33  9 41  5 22 38 15]]
#
# 5️⃣  Reshaped to (2x6):
# [[12 45  3 28 17 33]
#  [ 9 41  5 22 38 15]]
#
# =======================================================
#    ADDITIONAL STATISTICS
# =======================================================
#    Total Sum     : 268
#    Mean          : 22.33
#    Max Element   : 45
#    Min Element   : 3
#    Std Deviation : 13.76
