# Q8. Develop a dictionary-based inventory management system where users can
# add products, update quantity, search products, and display low-stock items.

def display_menu():
    """Display the inventory management menu."""
    print("\n--- INVENTORY MANAGEMENT MENU ---")
    print("1. Add Product")
    print("2. Update Quantity")
    print("3. Search Product")
    print("4. Display All Products")
    print("5. Display Low-Stock Items")
    print("6. Remove Product")
    print("7. Exit")
    print("-" * 35)


def add_product(inventory):
    """Add a new product to the inventory."""
    product_name = input("Enter product name: ").strip().title()

    if product_name in inventory:
        print(f"❌ '{product_name}' already exists! Use 'Update Quantity' option.")
        return

    price = float(input("Enter price: ₹"))
    quantity = int(input("Enter quantity: "))

    inventory[product_name] = {"price": price, "quantity": quantity}
    print(f"✅ '{product_name}' added successfully!")


def update_quantity(inventory):
    """Update the quantity of an existing product."""
    product_name = input("Enter product name to update: ").strip().title()

    if product_name not in inventory:
        print(f"❌ '{product_name}' not found in inventory!")
        return

    print(f"Current quantity of '{product_name}': {inventory[product_name]['quantity']}")
    new_quantity = int(input("Enter new quantity: "))
    inventory[product_name]["quantity"] = new_quantity
    print(f"✅ Quantity of '{product_name}' updated to {new_quantity}.")


def search_product(inventory):
    """Search for a product in the inventory."""
    product_name = input("Enter product name to search: ").strip().title()

    if product_name in inventory:
        product = inventory[product_name]
        print(f"\n📦 Product Found!")
        print(f"   Name    : {product_name}")
        print(f"   Price   : ₹{product['price']:.2f}")
        print(f"   Quantity: {product['quantity']}")
    else:
        print(f"❌ '{product_name}' not found in inventory!")


def display_all_products(inventory):
    """Display all products in the inventory."""
    if not inventory:
        print("\n📋 Inventory is empty!")
        return

    print(f"\n{'Product':<20} {'Price':>10} {'Quantity':>10}")
    print("-" * 45)
    for name, details in inventory.items():
        print(f"{name:<20} ₹{details['price']:>9.2f} {details['quantity']:>10}")
    print("-" * 45)
    print(f"Total Products: {len(inventory)}")


def display_low_stock(inventory, threshold=5):
    """Display products with quantity below a threshold."""
    low_stock_items = {name: details for name, details in inventory.items()
                       if details["quantity"] < threshold}

    if not low_stock_items:
        print(f"\n✅ No low-stock items (threshold: {threshold}).")
        return

    print(f"\n⚠️  LOW-STOCK ITEMS (Below {threshold} units):")
    print(f"{'Product':<20} {'Quantity':>10}")
    print("-" * 35)
    for name, details in low_stock_items.items():
        print(f"{name:<20} {details['quantity']:>10}")


def remove_product(inventory):
    """Remove a product from inventory."""
    product_name = input("Enter product name to remove: ").strip().title()

    if product_name in inventory:
        del inventory[product_name]
        print(f"✅ '{product_name}' removed from inventory.")
    else:
        print(f"❌ '{product_name}' not found in inventory!")


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   INVENTORY MANAGEMENT SYSTEM")
    print("=" * 50)

    # Dictionary to store inventory {product_name: {price, quantity}}
    inventory = {}

    while True:
        display_menu()
        choice = input("Enter your choice (1-7): ")

        if choice == '1':
            add_product(inventory)
        elif choice == '2':
            update_quantity(inventory)
        elif choice == '3':
            search_product(inventory)
        elif choice == '4':
            display_all_products(inventory)
        elif choice == '5':
            try:
                threshold = int(input("Enter low-stock threshold (default 5): ") or 5)
            except ValueError:
                threshold = 5
            display_low_stock(inventory, threshold)
        elif choice == '6':
            remove_product(inventory)
        elif choice == '7':
            print("\n" + "=" * 50)
            print("  Thank you for using Inventory System! Goodbye! 👋")
            print("=" * 50)
            break
        else:
            print("❌ Invalid choice! Please select from 1-7.")


# Expected Output:
# ==================================================
#    INVENTORY MANAGEMENT SYSTEM
# ==================================================
#
# --- INVENTORY MANAGEMENT MENU ---
# 1. Add Product
# 2. Update Quantity
# 3. Search Product
# 4. Display All Products
# 5. Display Low-Stock Items
# 6. Remove Product
# 7. Exit
# -----------------------------------
# Enter your choice (1-7): 1
# Enter product name: Laptop
# Enter price: ₹55000
# Enter quantity: 10
# ✅ 'Laptop' added successfully!
#
# Enter your choice (1-7): 1
# Enter product name: Mouse
# Enter price: ₹500
# Enter quantity: 3
# ✅ 'Mouse' added successfully!
#
# Enter your choice (1-7): 4
# Product              Price   Quantity
# ---------------------------------------------
# Laptop              ₹ 55000.00         10
# Mouse               ₹   500.00          3
# ---------------------------------------------
# Total Products: 2
#
# Enter your choice (1-7): 5
# ⚠️  LOW-STOCK ITEMS (Below 5 units):
# Product              Quantity
# -----------------------------------
# Mouse                        3
