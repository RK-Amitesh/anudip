# Q5. Write a Python program to merge two lists, remove duplicate values,
# and sort the final list in descending order.

def merge_remove_duplicates_sort(list1, list2):
    """Merge two lists, remove duplicates, and sort in descending order."""
    # Merge both lists
    merged_list = list1 + list2

    # Remove duplicates using a set, then convert back to list
    unique_list = list(set(merged_list))

    # Sort in descending order (manual bubble sort without built-in sort)
    n = len(unique_list)
    for i in range(n):
        for j in range(0, n - i - 1):
            if unique_list[j] < unique_list[j + 1]:
                unique_list[j], unique_list[j + 1] = unique_list[j + 1], unique_list[j]

    return merged_list, unique_list


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   MERGE, REMOVE DUPLICATES & SORT PROGRAM")
    print("=" * 50)

    # Accept two lists from user
    input1 = input("\nEnter elements of List 1 (space-separated): ")
    list1 = list(map(int, input1.split()))

    input2 = input("Enter elements of List 2 (space-separated): ")
    list2 = list(map(int, input2.split()))

    # Display original lists
    print(f"\nList 1: {list1}")
    print(f"List 2: {list2}")
    print("-" * 40)

    # Merge, remove duplicates, and sort
    merged, final_sorted = merge_remove_duplicates_sort(list1, list2)

    # Display results
    print(f"Merged List         : {merged}")
    print(f"After Removing Duplicates & Sorting (Descending): {final_sorted}")


# Expected Output:
# ==================================================
#    MERGE, REMOVE DUPLICATES & SORT PROGRAM
# ==================================================
#
# Enter elements of List 1 (space-separated): 5 3 8 1 9
# Enter elements of List 2 (space-separated): 3 7 8 2 5
#
# List 1: [5, 3, 8, 1, 9]
# List 2: [3, 7, 8, 2, 5]
# ----------------------------------------
# Merged List         : [5, 3, 8, 1, 9, 3, 7, 8, 2, 5]
# After Removing Duplicates & Sorting (Descending): [9, 8, 7, 5, 3, 2, 1]
