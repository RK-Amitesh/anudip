# Q24. Create a function for division of two numbers and use exception handling
# to validate inputs and avoid division by zero.

def divide_numbers(num1, num2):
    """Divide two numbers with proper exception handling."""
    try:
        # Validate that inputs are numeric
        number1 = float(num1)
        number2 = float(num2)

        # Check for division by zero
        if number2 == 0:
            raise ZeroDivisionError("Cannot divide by zero!")

        # Perform division
        result = number1 / number2
        integer_division = int(number1) // int(number2)
        remainder = number1 % number2

        return {
            "dividend": number1,
            "divisor": number2,
            "quotient": result,
            "integer_division": integer_division,
            "remainder": remainder,
            "success": True
        }

    except ZeroDivisionError as e:
        return {"error": f"ZeroDivisionError: {e}", "success": False}
    except ValueError:
        return {"error": "ValueError: Please enter valid numeric values!", "success": False}
    except TypeError:
        return {"error": "TypeError: Invalid input type!", "success": False}
    except Exception as e:
        return {"error": f"Unexpected Error: {e}", "success": False}


# Main program
if __name__ == "__main__":
    print("=" * 50)
    print("   DIVISION CALCULATOR WITH ERROR HANDLING")
    print("=" * 50)

    while True:
        print("\n--- Division Calculator ---")
        print("(Enter 'quit' to exit)")

        # Accept inputs
        num1 = input("\nEnter the first number (dividend): ")
        if num1.lower() == 'quit':
            break

        num2 = input("Enter the second number (divisor): ")
        if num2.lower() == 'quit':
            break

        # Perform division
        result = divide_numbers(num1, num2)

        print("\n" + "-" * 40)
        if result["success"]:
            print(f"   {result['dividend']} ÷ {result['divisor']} = {result['quotient']:.4f}")
            print(f"   Integer Division: {result['integer_division']}")
            print(f"   Remainder: {result['remainder']:.4f}")
            print("   ✅ Division successful!")
        else:
            print(f"   ❌ {result['error']}")
        print("-" * 40)

    print("\n" + "=" * 50)
    print("   Thank you for using Division Calculator! 👋")
    print("=" * 50)


# Expected Output:
# ==================================================
#    DIVISION CALCULATOR WITH ERROR HANDLING
# ==================================================
#
# --- Division Calculator ---
# (Enter 'quit' to exit)
#
# Enter the first number (dividend): 10
# Enter the second number (divisor): 3
#
# ----------------------------------------
#    10.0 ÷ 3.0 = 3.3333
#    Integer Division: 3
#    Remainder: 1.0000
#    ✅ Division successful!
# ----------------------------------------
#
# Enter the first number (dividend): 10
# Enter the second number (divisor): 0
#
# ----------------------------------------
#    ❌ ZeroDivisionError: Cannot divide by zero!
# ----------------------------------------
#
# Enter the first number (dividend): abc
# Enter the second number (divisor): 5
#
# ----------------------------------------
#    ❌ ValueError: Please enter valid numeric values!
# ----------------------------------------
