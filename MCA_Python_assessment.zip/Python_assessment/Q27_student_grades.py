# Q27. Create a program for storing student names and grades.
# Convert the data to identify students eligible for each grade category.

def get_grade(percentage):
    """Assign grade based on percentage."""
    if percentage >= 90:
        return 'A+'
    elif percentage >= 80:
        return 'A'
    elif percentage >= 70:
        return 'B+'
    elif percentage >= 60:
        return 'B'
    elif percentage >= 50:
        return 'C'
    elif percentage >= 40:
        return 'D'
    else:
        return 'F'


def get_grade_remark(grade):
    """Get remark for each grade."""
    remarks = {
        'A+': 'Outstanding',
        'A': 'Excellent',
        'B+': 'Very Good',
        'B': 'Good',
        'C': 'Average',
        'D': 'Below Average',
        'F': 'Fail'
    }
    return remarks.get(grade, 'N/A')


# Main program
if __name__ == "__main__":
    print("=" * 60)
    print("   STUDENT GRADE MANAGEMENT SYSTEM")
    print("=" * 60)

    students = {}  # Dictionary to store student data

    # Accept number of students
    n = int(input("\nEnter the number of students: "))

    # Input student data
    for i in range(n):
        print(f"\n--- Student {i + 1} ---")
        name = input("Enter student name: ").strip()
        marks = float(input("Enter marks (out of 100): "))

        if marks < 0 or marks > 100:
            print("❌ Invalid marks! Must be between 0-100.")
            continue

        grade = get_grade(marks)
        remark = get_grade_remark(grade)
        students[name] = {"marks": marks, "grade": grade, "remark": remark}

    # Display all students with grades
    print("\n" + "=" * 60)
    print("   STUDENT RESULTS")
    print("=" * 60)
    print(f"{'Name':<20} {'Marks':>8} {'Grade':>8} {'Remark':<15}")
    print("-" * 60)
    for name, data in students.items():
        print(f"{name:<20} {data['marks']:>8.2f} {data['grade']:>8} {data['remark']:<15}")
    print("-" * 60)

    # Categorize students by grade
    print("\n" + "=" * 60)
    print("   GRADE-WISE STUDENT CATEGORIES")
    print("=" * 60)

    grade_categories = {}
    for name, data in students.items():
        grade = data['grade']
        if grade not in grade_categories:
            grade_categories[grade] = []
        grade_categories[grade].append((name, data['marks']))

    # Sort grades
    grade_order = ['A+', 'A', 'B+', 'B', 'C', 'D', 'F']
    for grade in grade_order:
        if grade in grade_categories:
            remark = get_grade_remark(grade)
            print(f"\n📌 Grade {grade} ({remark}):")
            for name, marks in grade_categories[grade]:
                print(f"   - {name} ({marks:.2f} marks)")

    # Statistics
    all_marks = [data['marks'] for data in students.values()]
    print("\n" + "=" * 60)
    print("   CLASS STATISTICS")
    print("=" * 60)
    print(f"   Total Students  : {len(students)}")
    print(f"   Highest Marks   : {max(all_marks):.2f}")
    print(f"   Lowest Marks    : {min(all_marks):.2f}")
    print(f"   Average Marks   : {sum(all_marks) / len(all_marks):.2f}")
    passed = sum(1 for m in all_marks if m >= 40)
    failed = len(all_marks) - passed
    print(f"   Passed          : {passed}")
    print(f"   Failed          : {failed}")
    print(f"   Pass Percentage : {(passed / len(all_marks)) * 100:.2f}%")


# Expected Output:
# ============================================================
#    STUDENT GRADE MANAGEMENT SYSTEM
# ============================================================
#
# Enter the number of students: 6
# ... (input student names and marks)
#
# ============================================================
#    STUDENT RESULTS
# ============================================================
# Name                  Marks    Grade Remark
# ------------------------------------------------------------
# Rahul                 85.00       A  Excellent
# Priya                 92.00      A+  Outstanding
# Amit                  67.00      B+  Very Good
# Sneha                 45.00       D  Below Average
# Rohan                 38.00       F  Fail
# Kavita                78.00      B+  Very Good
# ------------------------------------------------------------
#
# ============================================================
#    GRADE-WISE STUDENT CATEGORIES
# ============================================================
#
# 📌 Grade A+ (Outstanding):
#    - Priya (92.00 marks)
# 📌 Grade A (Excellent):
#    - Rahul (85.00 marks)
# 📌 Grade B+ (Very Good):
#    - Amit (67.00 marks)
#    - Kavita (78.00 marks)
# 📌 Grade D (Below Average):
#    - Sneha (45.00 marks)
# 📌 Grade F (Fail):
#    - Rohan (38.00 marks)
