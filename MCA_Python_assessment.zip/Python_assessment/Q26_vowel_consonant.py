# Q26. Write a program to separate vowels and consonants from a sentence
# and store them in different lists.

def separate_vowels_consonants(sentence):
    """Separate vowels and consonants from a sentence into different lists."""
    vowels_list = []
    consonants_list = []
    vowels = set('aeiouAEIOU')

    for char in sentence:
        if char.isalpha():  # Only process alphabetical characters
            if char in vowels:
                vowels_list.append(char)
            else:
                consonants_list.append(char)

    return vowels_list, consonants_list


# Main program
if __name__ == "__main__":
    print("=" * 55)
    print("   VOWEL AND CONSONANT SEPARATOR")
    print("=" * 55)

    # Accept sentence from user
    sentence = input("\nEnter a sentence: ")

    # Separate vowels and consonants
    vowels_list, consonants_list = separate_vowels_consonants(sentence)

    # Display results
    print(f"\nOriginal Sentence: '{sentence}'")
    print("-" * 55)

    # Vowels
    print(f"\n🔴 Vowels ({len(vowels_list)}):")
    print(f"   List: {vowels_list}")
    # Unique vowels with counts
    vowel_counts = {}
    for v in vowels_list:
        v_lower = v.lower()
        vowel_counts[v_lower] = vowel_counts.get(v_lower, 0) + 1
    print(f"   Unique: {dict(vowel_counts)}")

    # Consonants
    print(f"\n🔵 Consonants ({len(consonants_list)}):")
    print(f"   List: {consonants_list}")
    # Unique consonants with counts
    consonant_counts = {}
    for c in consonants_list:
        c_lower = c.lower()
        consonant_counts[c_lower] = consonant_counts.get(c_lower, 0) + 1
    print(f"   Unique: {dict(consonant_counts)}")

    # Summary
    total_letters = len(vowels_list) + len(consonants_list)
    print(f"\n📊 Summary:")
    print(f"   Total Letters   : {total_letters}")
    print(f"   Vowels          : {len(vowels_list)} ({len(vowels_list)/total_letters*100:.1f}%)")
    print(f"   Consonants      : {len(consonants_list)} ({len(consonants_list)/total_letters*100:.1f}%)")


# Expected Output:
# =======================================================
#    VOWEL AND CONSONANT SEPARATOR
# =======================================================
#
# Enter a sentence: Hello World Python Programming
#
# Original Sentence: 'Hello World Python Programming'
# -------------------------------------------------------
#
# 🔴 Vowels (8):
#    List: ['e', 'o', 'o', 'y', 'o', 'o', 'a', 'i']
#    Unique: {'e': 1, 'o': 4, 'y': 1, 'a': 1, 'i': 1}
#
# 🔵 Consonants (19):
#    List: ['H', 'l', 'l', 'W', 'r', 'l', 'd', 'P', 't', 'h', 'n', 'P', 'r', 'g', 'r', 'm', 'm', 'n', 'g']
#    Unique: {'h': 2, 'l': 3, 'w': 1, 'r': 3, 'd': 1, 'p': 2, 't': 1, 'n': 2, 'g': 2, 'm': 2}
#
# 📊 Summary:
#    Total Letters   : 27
#    Vowels          : 8 (29.6%)
#    Consonants      : 19 (70.4%)
