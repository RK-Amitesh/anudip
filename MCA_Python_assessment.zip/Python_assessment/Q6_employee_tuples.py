# Q6. Create a program that stores employee records in tuples.
# Each tuple should contain employee ID, name, role, salary.
# Display employees whose salary is above the average salary.

def calculate_average_salary(employees):
    """Calculate the average salary of all employees."""
    total_salary = sum(emp[3] for emp in employees)
    return total_salary / len(employees)


def get_above_average_employees(employees, avg_salary):
    """Return employees whose salary is above average."""
    return [emp for emp in employees if emp[3] > avg_salary]


# Main program
if __name__ == "__main__":
    print("=" * 60)
    print("   EMPLOYEE RECORDS MANAGEMENT SYSTEM")
    print("=" * 60)

    employees = []  # List to store employee tuples

    # Accept number of employees
    n = int(input("\nEnter the number of employees: "))

    # Input employee records
    for i in range(n):
        print(f"\n--- Employee {i + 1} ---")
        emp_id = input("Enter Employee ID: ")
        name = input("Enter Employee Name: ")
        role = input("Enter Role/Designation: ")
        salary = float(input("Enter Salary: ₹"))

        # Store as tuple (immutable record)
        employee = (emp_id, name, role, salary)
        employees.append(employee)

    # Display all employee records
    print("\n" + "=" * 60)
    print("   ALL EMPLOYEE RECORDS")
    print("=" * 60)
    print(f"{'ID':<10} {'Name':<20} {'Role':<15} {'Salary':>10}")
    print("-" * 60)
    for emp in employees:
        print(f"{emp[0]:<10} {emp[1]:<20} {emp[2]:<15} ₹{emp[3]:>10.2f}")

    # Calculate average salary
    avg_salary = calculate_average_salary(employees)
    print("-" * 60)
    print(f"Average Salary: ₹{avg_salary:.2f}")

    # Display employees above average salary
    above_avg = get_above_average_employees(employees, avg_salary)
    print("\n" + "=" * 60)
    print("   EMPLOYEES WITH SALARY ABOVE AVERAGE")
    print("=" * 60)

    if above_avg:
        print(f"{'ID':<10} {'Name':<20} {'Role':<15} {'Salary':>10}")
        print("-" * 60)
        for emp in above_avg:
            print(f"{emp[0]:<10} {emp[1]:<20} {emp[2]:<15} ₹{emp[3]:>10.2f}")
    else:
        print("No employees found above average salary.")


# Expected Output:
# ============================================================
#    EMPLOYEE RECORDS MANAGEMENT SYSTEM
# ============================================================
#
# Enter the number of employees: 4
#
# --- Employee 1 ---
# Enter Employee ID: E001
# Enter Employee Name: Rahul Sharma
# Enter Role/Designation: Developer
# Enter Salary: ₹55000
#
# --- Employee 2 ---
# Enter Employee ID: E002
# Enter Employee Name: Priya Singh
# Enter Role/Designation: Manager
# Enter Salary: ₹75000
#
# --- Employee 3 ---
# Enter Employee ID: E003
# Enter Employee Name: Amit Kumar
# Enter Role/Designation: Analyst
# Enter Salary: ₹45000
#
# --- Employee 4 ---
# Enter Employee ID: E004
# Enter Employee Name: Sneha Patel
# Enter Role/Designation: Lead
# Enter Salary: ₹65000
#
# ============================================================
#    ALL EMPLOYEE RECORDS
# ============================================================
# ID         Name                 Role            Salary
# ------------------------------------------------------------
# E001       Rahul Sharma         Developer       ₹  55000.00
# E002       Priya Singh          Manager         ₹  75000.00
# E003       Amit Kumar           Analyst         ₹  45000.00
# E004       Sneha Patel          Lead            ₹  65000.00
# ------------------------------------------------------------
# Average Salary: ₹60000.00
#
# ============================================================
#    EMPLOYEES WITH SALARY ABOVE AVERAGE
# ============================================================
# ID         Name                 Role            Salary
# ------------------------------------------------------------
# E002       Priya Singh          Manager         ₹  75000.00
# E004       Sneha Patel          Lead            ₹  65000.00
