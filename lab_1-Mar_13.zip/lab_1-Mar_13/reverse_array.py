# Q10
# Reverse array from 1 to 10

import numpy as np

arr = np.arange(1,11)

reverse = arr[::-1]

print(reverse)

# Output
# [10 9 8 7 6 5 4 3 2 1]